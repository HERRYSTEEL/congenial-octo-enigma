# LawByNRHSTE Android

## Build

- Build runtime: JDK 21.
- Android Gradle Plugin: 8.4.2; Gradle wrapper: 8.6.
- Java and Kotlin bytecode target: 17.
- Debug install APK: `app/build/outputs/apk/debug/app-debug.apk`.
- Optimized release APK: `app/build/outputs/apk/release/app-release-unsigned.apk`.
- Android App Bundle: `app/build/outputs/bundle/release/app-release.aab`.

On Windows PowerShell, build with:

```powershell
$env:JAVA_HOME = 'C:\Program Files\Java\jdk-21.0.12.1'
$env:GRADLE_USER_HOME = Join-Path $env:TEMP 'lawbynrhste-gradle-build'
.\gradlew.bat --no-daemon '-Pkotlin.compiler.execution.strategy=in-process' :app:assembleDebug
.\gradlew.bat --no-daemon '-Pkotlin.compiler.execution.strategy=in-process' :app:assembleRelease :app:bundleRelease
```

The separate Gradle user home avoids a corrupt/missing Kotlin DSL accessor metadata cache found on this machine. In-process Kotlin compilation avoids the local Kotlin compiler-daemon connection failure. The first build may take several minutes while Gradle downloads dependencies.

The release variant enables R8 code shrinking and Android resource shrinking. Prefer the App Bundle for Play distribution so delivery can select device-specific resources and native libraries. The release APK and bundle are unsigned; production distribution requires signing with the application's protected release key. Do not use a debug key for a public release.

## Fixes in this build

- Aligns mobile profile fields with the website's public profile schema while keeping official names in the private profile path.
- Safely ignores malformed social-link entries that have no database key.
- Moves the nullable-string fallback helper to file scope so the profile editor compiles.
- Removes duplicate dashboard shortcuts already represented by navigation.
- Removes the admin console from dashboard shortcuts; only the platform-admin allowlist sees the entry in Settings, and the admin route remains independently guarded.
- Adds a Settings entry on the signed-in user's own profile, including the existing sign-out action.
- Displays conversation names and avatars from public profiles instead of labeling every participant "Member"; inbox profile listeners now load only each conversation participant, not the entire global profile tree.
- Catches inbox, chat, and directory permission errors so a denied Firebase read is shown as an error/fallback instead of crashing the app.
- Loads profile image URL aliases and public online state; displays presence in the inbox.
- Adds bounded (25 MB) image/audio/video/document attachment upload, photo previews, quick emoji insertion, and sent/delivered/seen indicators in chats.
- Plays voice messages in-app with asynchronous preparation, player cleanup, and visible playback errors instead of launching a fragile external intent.
- Plays video attachments inline and opens PDFs in an in-app, paginated reader. PDF pages are rendered at a bounded size, temporary cache files are removed when the reader closes, and previews are limited to 25 MB.
- Keeps non-PDF office documents dependent on a compatible external viewer; this build does not claim built-in Word or Excel rendering.
- Shows live Lobby reaction and comment counts, supports the configured emoji reactions, displays attached post images, and lets the author or platform admin delete a post.
- Keeps existing comments visible in the discussion dialog and reports engagement-read errors instead of silently treating them as empty.
- Requires new accounts to accept the Terms of Use and acknowledge the Privacy Notice; records the consent in the account's Realtime Database record and links the current legal documents from signup and Settings.
- Requires an internet connection and disables local Firebase database persistence, as requested.
- Uses the JDK 21 runtime while keeping Java/Kotlin bytecode at 17.

## Power, data, and package size

- Release code and resources are shrunk without removing app functionality.
- The App Bundle is the preferred distribution artifact for device-targeted downloads.
- Inbox data reads are scoped to active conversation participants instead of downloading all public profiles after sign-in.
- Attachments are limited to 25 MB per file to bound transfer time and data usage.
- Database disk persistence remains disabled to enforce online-only use. This means refreshed screens need network access and can use more data than an offline-cached app; do not re-enable caching without revisiting the online-only requirement.
- No dependencies or user-facing features were removed solely to reduce APK size.

## Verification and known follow-ups

- Debug build passed after the in-app voice, video, and PDF changes. The phone was not connected for this build, so these media flows have not been verified on-device.
- Device logcat identified `DatabaseException: Permission denied` in both the inbox's global `public_profiles` listener and the directory flow. The global inbox listener is removed; directory errors are now caught and displayed. The deployed database still appears to deny one or more profile reads, so member-directory data may remain unavailable until deployed rules are verified.
- Release APK and AAB size should be recorded only after the current source revision has been packaged; older artifact sizes are stale.
- A successful local build does not verify production Firebase rules, backend deployment, push delivery, or every screen's behavior against live user data.
- The previously reported Discussion Room permission-denied error still needs checking against the deployed Realtime Database rules. Do not weaken rules to work around it.
- Voice recording, FCM push delivery, verification requests/admin tier workflow, intelligent cross-content search, status updates, messaging backup, Office document rendering, and full authenticated media end-to-end testing still require additional app/backend work; they are not certified by this build.
- Future seasonal holiday themes are intentionally left as a follow-up, as requested.
