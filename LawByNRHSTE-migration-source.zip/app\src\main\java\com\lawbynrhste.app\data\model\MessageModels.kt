package com.lawbynrhste.app.data.model

import com.google.firebase.database.IgnoreExtraProperties

enum class MessageType(val rawValue: String) {
    TEXT("text"),
    IMAGE("image"),
    VOICE("voice"),
    FILE("file"),
    STATUS_REPLY("status_reply");

    companion object {
        fun fromRaw(raw: String?): MessageType = entries.find { it.rawValue == raw } ?: TEXT
    }
}

enum class DeliveryStatus {
    PENDING,
    SENT,
    DELIVERED,
    SEEN,
    FAILED
}

@IgnoreExtraProperties
data class ReplyReference(
    val key: String = "",
    val sender: String = "",
    val text: String = "",
    val type: String = "text"
)

@IgnoreExtraProperties
data class PrivateMessage(
    val id: String = "",
    val sender: String = "",
    val text: String? = null,
    val type: String = "text",
    val fileUrl: String? = null,
    val fileName: String? = null,
    val mimeType: String? = null,
    val duration: Int? = null,
    val statusOwner: String? = null,
    val statusId: String? = null,
    val replyTo: ReplyReference? = null,
    val delivered: Boolean = false,
    val seen: Boolean = false,
    val timestamp: Long = 0L,
    val deleted: Boolean = false,
    val deletedFor: Map<String, Boolean>? = null,
    val markedForDeletion: Boolean = false,
    val markedBy: String? = null,
    // Client-side delivery state
    val localStatus: DeliveryStatus = if (seen) DeliveryStatus.SEEN else if (delivered) DeliveryStatus.DELIVERED else DeliveryStatus.SENT
)

@IgnoreExtraProperties
data class ConversationOverview(
    val otherUid: String = "",
    val preview: String = "",
    val sender: String = "",
    val timestamp: Long = 0L,
    val unread: Boolean = false,
    // Client-side enriched profile
    val otherUser: UserProfile? = null
)

data class OutgoingMessageDraft(
    val stableId: String,
    val roomPath: String,
    val recipientUid: String,
    val message: PrivateMessage,
    val retryCount: Int = 0,
    val lastAttemptMillis: Long = System.currentTimeMillis()
)

