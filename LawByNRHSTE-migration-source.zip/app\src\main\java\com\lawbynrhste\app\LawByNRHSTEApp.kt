package com.lawbynrhste.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.lawbynrhste.app.data.firebase.FirebaseManager

class LawByNRHSTEApp : Application() {

    companion object {
        const val CHANNEL_MESSAGES = "lawby_messages"
        const val CHANNEL_COMMUNITY = "lawby_community"
        const val CHANNEL_ALERTS = "lawby_alerts"
    }

    override fun onCreate() {
        super.onCreate()
        FirebaseManager.initialize(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val messagesChannel = NotificationChannel(
                CHANNEL_MESSAGES,
                "Direct Messages",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for private legal communications and replies"
                enableLights(true)
                enableVibration(true)
            }

            val communityChannel = NotificationChannel(
                CHANNEL_COMMUNITY,
                "Community & Lobby",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for comments, reactions, and mentions"
            }

            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS,
                "Platform Announcements",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical system alerts and announcements"
            }

            notificationManager?.createNotificationChannels(
                listOf(messagesChannel, communityChannel, alertsChannel)
            )
        }
    }
}

