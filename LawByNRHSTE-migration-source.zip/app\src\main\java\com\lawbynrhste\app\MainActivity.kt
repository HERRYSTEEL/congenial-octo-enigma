package com.lawbynrhste.app

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.lawbynrhste.app.data.model.AuthSessionState
import com.lawbynrhste.app.data.repository.AdminRepository
import com.lawbynrhste.app.data.repository.ArticlesRepository
import com.lawbynrhste.app.data.repository.AuthRepository
import com.lawbynrhste.app.data.repository.DirectoryRepository
import com.lawbynrhste.app.data.repository.ForumRepository
import com.lawbynrhste.app.data.repository.LobbyRepository
import com.lawbynrhste.app.data.repository.MessagingRepository
import com.lawbynrhste.app.data.repository.NotificationsRepository
import com.lawbynrhste.app.data.repository.ResourcesRepository
import com.lawbynrhste.app.data.repository.SettingsRepository
import com.lawbynrhste.app.ui.components.LawLoadingIndicator
import com.lawbynrhste.app.ui.components.ConnectivityStatus
import com.lawbynrhste.app.ui.components.ConnectivityStatusBanner
import com.lawbynrhste.app.ui.components.ErrorBanner
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.screens.account.AdminTerminalScreen
import com.lawbynrhste.app.ui.screens.account.ChatRoomScreen
import com.lawbynrhste.app.ui.screens.account.MessagesScreen
import com.lawbynrhste.app.ui.screens.account.SettingsScreen
import com.lawbynrhste.app.ui.screens.auth.ForgotPasswordScreen
import com.lawbynrhste.app.ui.screens.auth.SignInScreen
import com.lawbynrhste.app.ui.screens.auth.SignUpScreen
import com.lawbynrhste.app.ui.screens.community.CreatePostScreen
import com.lawbynrhste.app.ui.screens.community.DirectoryScreen
import com.lawbynrhste.app.ui.screens.community.DiscussionRoomScreen
import com.lawbynrhste.app.ui.screens.community.LobbyScreen
import com.lawbynrhste.app.ui.screens.community.ProfileScreen
import com.lawbynrhste.app.ui.screens.content.ArticleDetailScreen
import com.lawbynrhste.app.ui.screens.content.ArticleEditorScreen
import com.lawbynrhste.app.ui.screens.content.ArticlesScreen
import com.lawbynrhste.app.ui.screens.content.NotificationsScreen
import com.lawbynrhste.app.ui.screens.content.ResourcesScreen
import com.lawbynrhste.app.ui.screens.dashboard.DashboardScreen
import com.lawbynrhste.app.ui.theme.LawByNRHSTETheme
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.catch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LawByNRHSTETheme {
                LawByNRHSTEAppContent()
            }
        }
    }
}

@Composable
private fun LawByNRHSTEAppContent() {
    val tag = "LawByNRHSTEApp"
    val context = LocalContext.current
    val connectivityStatus = remember(context) {
        ConnectivityStatus(context.applicationContext)
    }
    val isOnline by connectivityStatus.isOnline.collectAsState(initial = true)
    val authRepository = remember { AuthRepository() }
    val adminRepository = remember { AdminRepository() }
    val articlesRepository = remember { ArticlesRepository() }
    val directoryRepository = remember { DirectoryRepository() }
    val lobbyRepository = remember { LobbyRepository() }
    val forumRepository = remember { ForumRepository() }
    val messagingRepository = remember { MessagingRepository() }
    val notificationsRepository = remember { NotificationsRepository() }
    val resourcesRepository = remember { ResourcesRepository() }
    val settingsRepository = remember(context) { SettingsRepository(context.applicationContext) }
    val sessionState by authRepository.observeSessionState()
        .collectAsState(initial = AuthSessionState())

    if (!isOnline) {
        Column(Modifier.fillMaxSize()) {
            ConnectivityStatusBanner()
            Box(
                Modifier.weight(1f).fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "An internet connection is required to use LawBy NRHSTE. Reconnect and try again.",
                    color = com.lawbynrhste.app.ui.theme.TextPrimary
                )
            }
        }
        return
    }

    if (sessionState.isLoading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            LawLoadingIndicator(message = "Securing your session...")
        }
        return
    }

    val currentUid = sessionState.uid
    var backgroundDataError by remember(currentUid) { mutableStateOf<String?>(null) }
    val notificationsFlow = remember(currentUid) {
        if (currentUid.isNullOrBlank()) flowOf(emptyList())
        else notificationsRepository.observeNotifications(currentUid).catch { failure ->
            Log.e(tag, "Notification stream failed", failure)
            backgroundDataError = failure.localizedMessage ?: "Notifications are temporarily unavailable."
            emit(emptyList())
        }
    }
    val inboxFlow = remember(currentUid) {
        if (currentUid.isNullOrBlank()) flowOf(emptyList())
        else messagingRepository.observeInboxOverviews(currentUid).catch { failure ->
            Log.e(tag, "Inbox stream failed", failure)
            backgroundDataError = failure.localizedMessage ?: "Your inbox is temporarily unavailable."
            emit(emptyList())
        }
    }
    val notifications by notificationsFlow.collectAsState(initial = emptyList())
    val conversations by inboxFlow.collectAsState(initial = emptyList())
    val unreadNotifications = notifications.count { !it.read }
    val unreadMessages = conversations.count { it.unread }
    val navController = rememberNavController()
    val startDestination = if (currentUid == null) Screen.SignIn.route else Screen.Dashboard.route

    Column(Modifier.fillMaxSize()) {
        backgroundDataError?.let { ErrorBanner(it) }
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.weight(1f)
        ) {
        composable(Screen.SignIn.route) {
            SignInScreen(
                authRepository = authRepository,
                onSignInSuccess = {
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.SignIn.route) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) },
                onNavigateToForgotPassword = { navController.navigate(Screen.ForgotPassword.route) }
            )
        }
        composable(Screen.SignUp.route) {
            SignUpScreen(
                authRepository = authRepository,
                onSignUpSuccess = {
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.SignIn.route) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                onNavigateToSignIn = { navController.popBackStack() }
            )
        }
        composable(Screen.ForgotPassword.route) {
            ForgotPasswordScreen(authRepository = authRepository, onNavigateBack = { navController.popBackStack() })
        }
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                sessionState = sessionState,
                adminRepository = adminRepository,
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages,
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(Screen.Profile.route) {
            ProfileScreen(
                uid = currentUid.orEmpty(),
                repository = directoryRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onBack = { navController.popBackStack() },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(Screen.Lobby.route) {
            LobbyScreen(
                repository = lobbyRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onCreatePost = { navController.navigate(Screen.CreatePost.route) },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(Screen.Discussions.route) {
            DiscussionRoomScreen(
                repository = forumRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(Screen.CreatePost.route) {
            CreatePostScreen(
                repository = lobbyRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onBack = { navController.popBackStack() },
                onPublished = { navController.popBackStack() }
            )
        }
        composable(Screen.Articles.route) {
            ArticlesScreen(
                repository = articlesRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onArticleSelected = { id -> navController.navigate(Screen.ArticleDetail.createRoute(id)) },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(
            route = Screen.ArticleDetail.route,
            arguments = listOf(navArgument("articleId") { type = NavType.StringType })
        ) { entry ->
            ArticleDetailScreen(
                articleId = entry.arguments?.getString("articleId").orEmpty(),
                repository = articlesRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onBack = { navController.popBackStack() },
                onEdit = { id -> navController.navigate(Screen.ArticleEditor.createRoute(id)) },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(
            route = Screen.ArticleEditor.route,
            arguments = listOf(
                navArgument("articleId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { entry ->
            ArticleEditorScreen(
                articleId = entry.arguments?.getString("articleId"),
                repository = articlesRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onBack = { navController.popBackStack() },
                onSaved = { id ->
                    navController.navigate(Screen.ArticleDetail.createRoute(id)) {
                        popUpTo(Screen.Articles.route)
                    }
                }
            )
        }
        composable(Screen.Resources.route) {
            ResourcesScreen(
                repository = resourcesRepository,
                onNavigate = { route -> navController.navigate(route) },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(Screen.Directory.route) {
            DirectoryScreen(
                repository = directoryRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onMemberSelected = { uid -> navController.navigate(Screen.MemberProfile.createRoute(uid)) },
                onChatSelected = { uid, name -> navController.navigate(Screen.ChatRoom.createRoute(uid, name)) },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(
            route = Screen.MemberProfile.route,
            arguments = listOf(navArgument("uid") { type = NavType.StringType })
        ) { entry ->
            ProfileScreen(
                uid = entry.arguments?.getString("uid").orEmpty(),
                repository = directoryRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onBack = { navController.popBackStack() },
                unreadNotificationsCount = unreadNotifications,
                unreadMessagesCount = unreadMessages
            )
        }
        composable(Screen.Messages.route) {
            MessagesScreen(
                repository = messagingRepository,
                currentUid = currentUid.orEmpty(),
                onNavigate = { route -> navController.navigate(route) },
                onOpenChat = { uid, name -> navController.navigate(Screen.ChatRoom.createRoute(uid, name)) },
                unreadNotificationsCount = unreadNotifications
            )
        }
        composable(
            route = Screen.ChatRoom.route,
            arguments = listOf(
                navArgument("recipientUid") { type = NavType.StringType },
                navArgument("recipientName") { type = NavType.StringType }
            )
        ) { entry ->
            ChatRoomScreen(
                repository = messagingRepository,
                currentUid = currentUid.orEmpty(),
                recipientUid = entry.arguments?.getString("recipientUid").orEmpty(),
                recipientName = entry.arguments?.getString("recipientName") ?: "Member",
                onNavigate = { route -> navController.navigate(route) },
                onBack = { navController.popBackStack() },
                unreadNotificationsCount = unreadNotifications
            )
        }
        composable(Screen.Notifications.route) {
            if (currentUid.isNullOrBlank()) {
                SignedOutScreen()
            } else {
                NotificationsScreen(
                    repository = notificationsRepository,
                    currentUid = currentUid,
                    onNavigate = { route -> navController.navigate(route) },
                    onPostNotification = { navController.navigate(Screen.Lobby.route) },
                    unreadMessagesCount = unreadMessages
                )
            }
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                repository = settingsRepository,
                authRepository = authRepository,
                sessionState = sessionState,
                onNavigate = { route -> navController.navigate(route) },
                onSignedOut = {
                    navController.navigate(Screen.SignIn.route) {
                        popUpTo(Screen.Dashboard.route) { inclusive = true }
                        launchSingleTop = true
                    }
                },
                unreadNotificationsCount = unreadNotifications
            )
        }
        composable(Screen.AdminTerminal.route) {
            if (sessionState.isPlatformAdmin) {
                AdminTerminalScreen(
                    repository = adminRepository,
                    sessionState = sessionState,
                    onNavigate = { route -> navController.navigate(route) },
                    onBack = { navController.popBackStack() }
                )
            } else {
                SignedOutScreen()
            }
        }
    }
}

}

@Composable
private fun SignedOutScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("This section is available after signing in.")
    }
}
