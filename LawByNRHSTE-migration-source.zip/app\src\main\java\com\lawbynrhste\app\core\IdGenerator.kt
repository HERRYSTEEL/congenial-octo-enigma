package com.lawbynrhste.app.core

import java.util.UUID

object IdGenerator {
    /**
     * Generates a stable client message ID prefixed by timestamp for chronological ordering,
     * matching Firebase RTDB push key lexicographical properties.
     */
    fun createStableMessageId(): String {
        val timestamp = System.currentTimeMillis()
        val randomUuid = UUID.randomUUID().toString().replace("-", "").take(12)
        return "msg_${timestamp}_$randomUuid"
    }

    /**
     * Canonicalizes participant UIDs into sorted room path: "lowerUid/higherUid".
     * This enforces consistency between website and Android app.
     */
    fun canonicalRoomId(uid1: String, uid2: String): String {
        require(uid1.isNotBlank() && uid2.isNotBlank()) { "User IDs must not be blank" }
        return if (uid1 < uid2) "$uid1/$uid2" else "$uid2/$uid1"
    }

    /**
     * Checks if a legacy room ID (e.g., using underscore "uid1_uid2") matches the two participants.
     */
    fun matchesLegacyRoom(legacyRoom: String, uid1: String, uid2: String): Boolean {
        return legacyRoom == "${uid1}_${uid2}" || legacyRoom == "${uid2}_${uid1}"
    }
}

