package com.lawbynrhste.app.core

sealed interface Result<out T> {
    data class Success<out T>(val data: T) : Result<T>
    data class Error(val exception: Throwable, val message: String = exception.message ?: "An unexpected error occurred") : Result<Nothing>
    data object Loading : Result<Nothing>
}

