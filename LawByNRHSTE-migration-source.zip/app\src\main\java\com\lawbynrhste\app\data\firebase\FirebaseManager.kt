package com.lawbynrhste.app.data.firebase

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage

object FirebaseManager {
    private const val TAG = "FirebaseManager"

    const val PROJECT_ID = "lawbynrhste"
    const val DATABASE_URL = "https://lawbynrhste-default-rtdb.europe-west1.firebasedatabase.app"
    const val STORAGE_BUCKET = "lawbynrhste.appspot.com"
    const val API_KEY = "AIzaSyD-OAHLz4CNuFUeLRrZTY1cfgsH0dSyM0I"
    const val APPLICATION_ID = "1:417935272671:android:lawbynrhsteapp01"

    @Volatile
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            try {
                if (FirebaseApp.getApps(context).isEmpty()) {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId(APPLICATION_ID)
                        .setApiKey(API_KEY)
                        .setProjectId(PROJECT_ID)
                        .setDatabaseUrl(DATABASE_URL)
                        .setStorageBucket(STORAGE_BUCKET)
                        .build()
                    FirebaseApp.initializeApp(context, options)
                    Log.i(TAG, "Initialized Firebase programmatically with project $PROJECT_ID")
                } else {
                    Log.i(TAG, "Firebase already initialized via google-services plugin")
                }

                // Keep app data online-only; do not retain the Realtime Database cache on disk.
                try {
                    val rtdb = Firebase.database(DATABASE_URL)
                    rtdb.setPersistenceEnabled(false)
                } catch (e: Exception) {
                    Log.w(TAG, "RTDB persistence already configured or cannot be altered: ${e.message}")
                }

                // Keep Firestore data online-only as well.
                try {
                    val firestore = Firebase.firestore
                    val settings = FirebaseFirestoreSettings.Builder()
                        .setPersistenceEnabled(false)
                        .build()
                    firestore.firestoreSettings = settings
                } catch (e: Exception) {
                    Log.w(TAG, "Firestore settings configuration warning: ${e.message}")
                }

                initialized = true
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initialize FirebaseManager", e)
            }
        }
    }

    val auth: FirebaseAuth
        get() = Firebase.auth

    val database: FirebaseDatabase
        get() = Firebase.database(DATABASE_URL)

    val firestore: FirebaseFirestore
        get() = Firebase.firestore

    val storage: FirebaseStorage
        get() = Firebase.storage("gs://$STORAGE_BUCKET")
}
