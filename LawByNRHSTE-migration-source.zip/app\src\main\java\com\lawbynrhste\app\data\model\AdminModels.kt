package com.lawbynrhste.app.data.model

import com.google.firebase.database.IgnoreExtraProperties

val PLATFORM_ADMIN_EMAILS = setOf("herryroewliesteel@gmail.com", "nrhste@legal.com")

@IgnoreExtraProperties
data class PlatformAnnouncement(
    val message: String = "",
    val timestamp: Long = 0L,
    val expiresAt: Long = 0L
)

@IgnoreExtraProperties
data class MaintenanceStatus(
    val active: Boolean = false,
    val message: String = ""
)

@IgnoreExtraProperties
data class BugReport(
    val id: String = "",
    val reporterUid: String = "",
    val reportedUid: String = "",
    val reason: String = "",
    val timestamp: Long = 0L
)

data class DirectoryMember(
    val uid: String,
    val profile: UserProfile,
    val isFollowing: Boolean = false,
    val followerCount: Int = 0
)
