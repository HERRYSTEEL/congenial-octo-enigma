package com.lawbynrhste.app.data.model

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class AiDetectionResult(
    val isAIGenerated: Boolean = false,
    val aiScore: Double = 0.0,
    val plagiarismScore: Double = 0.0
)

@IgnoreExtraProperties
data class Article(
    val id: String = "",
    val title: String = "",
    val category: String = "Student Research",
    val content: String = "",
    val author: String = "",
    val authorUid: String = "",
    val timestamp: Long = 0L,
    val wordCount: Int = 0,
    val aiDetection: AiDetectionResult? = null,
    val authorVerification: String? = null,
    val collaborators: Map<String, String> = emptyMap()
)

