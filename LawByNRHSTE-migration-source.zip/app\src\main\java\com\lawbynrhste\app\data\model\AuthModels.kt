package com.lawbynrhste.app.data.model

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class UserProfile(
    val name: String = "",
    val username: String = "",
    val role: String = "user",
    val joined: Long = 0L,
    val photo: String = "",
    val bio: String = "",
    val education: String = "",
    val field: String = "",
    val status: String = "offline",
    val friendCount: Int = 0,
    val verification: String? = null,
    val showOfficialName: Boolean? = null,
    val occupation: String = "",
    val highSchool: String = "",
    val college: String = "",
    val university: String = "",
    val fieldOfStudy: String = "",
    val interests: String = "",
    val socialLinks: Map<String, String> = emptyMap()
)

@IgnoreExtraProperties
data class AgreementRecord(
    val accepted: Boolean = false,
    val timestamp: Long = 0L
)

@IgnoreExtraProperties
data class AlertRecord(
    val message: String = ""
)

@IgnoreExtraProperties
data class UserAccountData(
    val uid: String = "",
    val email: String = "",
    val profile: UserProfile = UserProfile(),
    val accountType: String = "standard",
    val isFrozen: Boolean = false,
    val alert: AlertRecord? = null,
    val agreement: AgreementRecord? = null,
    val cookiesConsent: AgreementRecord? = null,
    val savedPosts: Map<String, Boolean> = emptyMap()
)

data class AuthSessionState(
    val uid: String? = null,
    val email: String? = null,
    val userAccount: UserAccountData? = null,
    val isLoading: Boolean = true,
    val isPlatformAdmin: Boolean = false,
    val isFrozen: Boolean = false,
    val pendingAlert: String? = null
)
