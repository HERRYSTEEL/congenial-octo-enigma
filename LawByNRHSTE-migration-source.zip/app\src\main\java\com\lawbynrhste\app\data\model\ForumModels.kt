package com.lawbynrhste.app.data.model

data class ForumReply(
    val id: String,
    val uid: String,
    val authorName: String,
    val body: String,
    val timestamp: Long
)

data class ForumDiscussion(
    val id: String,
    val authorUid: String,
    val authorName: String,
    val title: String,
    val body: String,
    val createdAt: Long,
    val replies: List<ForumReply>
)
