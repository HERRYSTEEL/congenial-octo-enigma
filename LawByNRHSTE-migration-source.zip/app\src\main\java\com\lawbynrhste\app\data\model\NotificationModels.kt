package com.lawbynrhste.app.data.model

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class NotificationItem(
    val id: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "general",
    val fromUid: String? = null,
    val postId: String? = null,
    val timestamp: Long = 0L,
    val read: Boolean = false
)

@IgnoreExtraProperties
data class AdminSupportMessage(
    val id: String = "",
    val from: String = "Support Admin",
    val text: String = "",
    val timestamp: Long = 0L,
    val unread: Boolean = false,
    val anonymous: Boolean = false
)

