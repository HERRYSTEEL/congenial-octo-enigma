package com.lawbynrhste.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties

val SUPPORTED_REACTIONS = listOf("👍", "❤️", "😂", "😮", "😢", "😡")

@IgnoreExtraProperties
data class Post(
    val id: String = "",
    val uid: String = "",
    val author: String = "",
    val avatar: String = "",
    val text: String = "",
    val mentions: List<String> = emptyList(),
    val image: String? = null,
    val sharedFrom: String? = null,
    val sharedFromUid: String? = null,
    val sharedFromAuthor: String? = null,
    val timestamp: Timestamp? = null,
    val deleted: Boolean = false,
    // Client-side enriched state
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val userReaction: String? = null,
    val isSupported: Boolean = false,
    val reactionsSummary: Map<String, Int> = emptyMap()
)

@IgnoreExtraProperties
data class PostLike(
    val uid: String = "",
    val emoji: String = "👍",
    val timestamp: Timestamp? = null
)

@IgnoreExtraProperties
data class PostComment(
    val id: String = "",
    val uid: String = "",
    val author: String = "",
    val text: String = "",
    val timestamp: Timestamp? = null,
    val reactions: Map<String, String> = emptyMap(), // userId -> emoji
    val userReaction: String? = null,
    val replies: List<PostReply> = emptyList()
)

@IgnoreExtraProperties
data class PostReply(
    val id: String = "",
    val uid: String = "",
    val author: String = "",
    val text: String = "",
    val timestamp: Timestamp? = null,
    val reactions: Map<String, String> = emptyMap(), // userId -> emoji
    val userReaction: String? = null
)

