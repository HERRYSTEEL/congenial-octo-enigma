package com.lawbynrhste.app.data.model

import com.google.firebase.database.IgnoreExtraProperties

val LEGAL_CATEGORIES = listOf(
    "All",
    "Constitutional Law",
    "Criminal Justice",
    "Corporate Law",
    "Intellectual Property",
    "Environmental Law",
    "International Law"
)

data class CuratedLegalResource(
    val title: String,
    val description: String,
    val url: String,
    val iconName: String,
    val category: String
)

@IgnoreExtraProperties
data class LegalNewsItem(
    val id: String = "",
    val title: String = "",
    val summary: String = "",
    val date: String = "",
    val source: String = "",
    val link: String = "",
    val category: String = "Constitutional Law",
    val timestamp: Long = 0L
)
