package com.lawbynrhste.app.data.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.BugReport
import com.lawbynrhste.app.data.model.MaintenanceStatus
import com.lawbynrhste.app.data.model.PLATFORM_ADMIN_EMAILS
import com.lawbynrhste.app.data.model.PlatformAnnouncement
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AdminRepository(
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {

    fun isAuthorizedAdmin(email: String?): Boolean {
        return PLATFORM_ADMIN_EMAILS.contains(email?.lowercase() ?: "")
    }

    fun observeMaintenance(): Flow<MaintenanceStatus> = callbackFlow {
        val ref = rtdb.getReference("admin/maintenance")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val active = snapshot.child("active").getValue(Boolean::class.java) ?: false
                val message = snapshot.child("message").getValue(String::class.java) ?: ""
                trySend(MaintenanceStatus(active = active, message = message))
            }

            override fun onCancelled(error: DatabaseError) {
                trySend(MaintenanceStatus())
            }
        }

        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    fun observeAnnouncement(): Flow<PlatformAnnouncement?> = callbackFlow {
        val ref = rtdb.getReference("platform_settings/announcements/current")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    trySend(null)
                    return
                }
                val message = snapshot.child("message").getValue(String::class.java) ?: ""
                val timestamp = snapshot.child("timestamp").getValue(Long::class.java) ?: 0L
                val expiresAt = snapshot.child("expiresAt").getValue(Long::class.java) ?: 0L

                val isActive = message.isNotBlank() && (expiresAt == 0L || expiresAt > System.currentTimeMillis())
                if (isActive) {
                    trySend(PlatformAnnouncement(message = message, timestamp = timestamp, expiresAt = expiresAt))
                } else {
                    trySend(null)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                trySend(null)
            }
        }

        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    fun observeBugReports(adminEmail: String?): Flow<List<BugReport>> = callbackFlow {
        if (!isAuthorizedAdmin(adminEmail)) {
            close(SecurityException("Unauthorized access to admin audit logs."))
            return@callbackFlow
        }

        val ref = rtdb.getReference("reports")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val reports = mutableListOf<BugReport>()
                for (child in snapshot.children) {
                    val id = child.key ?: continue
                    val reporterUid = child.child("reporterUid").getValue(String::class.java) ?: ""
                    val reportedUid = child.child("reportedUid").getValue(String::class.java) ?: ""
                    val reason = child.child("reason").getValue(String::class.java) ?: ""
                    val timestamp = child.child("timestamp").getValue(Long::class.java) ?: 0L
                    reports.add(
                        BugReport(
                            id = id,
                            reporterUid = reporterUid,
                            reportedUid = reportedUid,
                            reason = reason,
                            timestamp = timestamp
                        )
                    )
                }
                reports.sortByDescending { it.timestamp }
                trySend(reports)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    suspend fun setAccountFrozen(targetUid: String, frozen: Boolean, adminEmail: String?): Result<Unit> {
        if (!isAuthorizedAdmin(adminEmail)) return Result.Error(SecurityException("Unauthorized: Admin privileges required"))
        return try {
            rtdb.getReference("users/$targetUid/isFrozen").setValue(frozen).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to toggle account suspension: ${e.message}")
        }
    }

    suspend fun sendPushAlert(targetUid: String, message: String, adminEmail: String?): Result<Unit> {
        if (!isAuthorizedAdmin(adminEmail)) return Result.Error(SecurityException("Unauthorized: Admin privileges required"))
        return try {
            rtdb.getReference("users/$targetUid/alert").setValue(mapOf("message" to message.trim())).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to send alert: ${e.message}")
        }
    }

    suspend fun setVerificationBadge(targetUid: String, badge: String?, adminEmail: String?): Result<Unit> {
        if (!isAuthorizedAdmin(adminEmail)) return Result.Error(SecurityException("Unauthorized: Admin privileges required"))
        return try {
            rtdb.getReference("users/$targetUid/profile/verification").setValue(badge).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to set verification badge: ${e.message}")
        }
    }

    suspend fun publishAnnouncement(message: String, durationHours: Int, adminEmail: String?): Result<Unit> {
        if (!isAuthorizedAdmin(adminEmail)) return Result.Error(SecurityException("Unauthorized: Admin privileges required"))
        return try {
            val timestamp = System.currentTimeMillis()
            val expiresAt = timestamp + (durationHours.toLong() * 60 * 60 * 1000)
            val announcement = mapOf(
                "message" to message.trim(),
                "timestamp" to timestamp,
                "expiresAt" to expiresAt
            )
            rtdb.getReference("platform_settings/announcements/current").setValue(announcement).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to publish announcement: ${e.message}")
        }
    }

    suspend fun toggleMaintenance(active: Boolean, message: String, adminEmail: String?): Result<Unit> {
        if (!isAuthorizedAdmin(adminEmail)) return Result.Error(SecurityException("Unauthorized: Admin privileges required"))
        return try {
            val payload = mapOf("active" to active, "message" to message.trim())
            rtdb.getReference("admin/maintenance").setValue(payload).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to toggle maintenance mode: ${e.message}")
        }
    }
}

