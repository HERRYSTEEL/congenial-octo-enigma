package com.lawbynrhste.app.data.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.functions.FirebaseFunctions
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.AiDetectionResult
import com.lawbynrhste.app.data.model.Article
import com.lawbynrhste.app.data.model.PLATFORM_ADMIN_EMAILS
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ArticlesRepository(
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {

    fun observeArticles(): Flow<List<Article>> = callbackFlow {
        val ref = rtdb.getReference("vault_research")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val articles = mutableListOf<Article>()
                for (child in snapshot.children) {
                    val id = child.key ?: continue
                    val status = child.child("status").getValue(String::class.java)
                    if (status != null && status != "published") continue
                    val title = child.child("title").getValue(String::class.java) ?: "Untitled Brief"
                    val category = child.child("category").getValue(String::class.java) ?: "Student Research"
                    val content = child.child("content").getValue(String::class.java) ?: ""
                    val author = child.child("author").getValue(String::class.java) ?: "Student Contributor"
                    val authorUid = child.child("authorUid").getValue(String::class.java) ?: ""
                    val timestamp = child.child("timestamp").getValue(Long::class.java) ?: 0L
                    val wordCount = child.child("wordCount").getValue(Int::class.java) ?: 0
                    val authorVerification = child.child("authorVerification").getValue(String::class.java)

                    val aiSnap = child.child("aiDetection")
                    val aiDetection = if (aiSnap.exists()) {
                        AiDetectionResult(
                            isAIGenerated = aiSnap.child("isAIGenerated").getValue(Boolean::class.java) ?: false,
                            aiScore = aiSnap.child("aiScore").getValue(Double::class.java) ?: 0.0,
                            plagiarismScore = aiSnap.child("plagiarismScore").getValue(Double::class.java) ?: 0.0
                        )
                    } else null

                    val collabMap = mutableMapOf<String, String>()
                    val collabSnap = child.child("collaborators")
                    for (c in collabSnap.children) {
                        val cKey = c.key ?: continue
                        collabMap[cKey] = c.getValue(String::class.java) ?: ""
                    }

                    articles.add(
                        Article(
                            id = id,
                            title = title,
                            category = category,
                            content = content,
                            author = author,
                            authorUid = authorUid,
                            timestamp = timestamp,
                            wordCount = wordCount,
                            aiDetection = aiDetection,
                            authorVerification = authorVerification,
                            collaborators = collabMap
                        )
                    )
                }

                articles.sortByDescending { it.timestamp }
                trySend(articles)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        ref.addValueEventListener(listener)
        awaitClose {
            ref.removeEventListener(listener)
        }
    }

    suspend fun getArticleById(id: String): Result<Article> {
        return try {
            val snapshot = rtdb.getReference("vault_research/$id").get().await()
            if (!snapshot.exists()) return Result.Error(NoSuchElementException("Article not found"))
            val status = snapshot.child("status").getValue(String::class.java)
            if (status != null && status != "published") {
                return Result.Error(NoSuchElementException("Article not found"))
            }

            val title = snapshot.child("title").getValue(String::class.java) ?: "Untitled"
            val category = snapshot.child("category").getValue(String::class.java) ?: "Student Research"
            val content = snapshot.child("content").getValue(String::class.java) ?: ""
            val author = snapshot.child("author").getValue(String::class.java) ?: "Student Contributor"
            val authorUid = snapshot.child("authorUid").getValue(String::class.java) ?: ""
            val timestamp = snapshot.child("timestamp").getValue(Long::class.java) ?: 0L
            val wordCount = snapshot.child("wordCount").getValue(Int::class.java) ?: 0

            Result.Success(
                Article(
                    id = id,
                    title = title,
                    category = category,
                    content = content,
                    author = author,
                    authorUid = authorUid,
                    timestamp = timestamp,
                    wordCount = wordCount
                )
            )
        } catch (e: Exception) {
            Result.Error(e, "Failed to load article: ${e.message}")
        }
    }

    suspend fun publishArticle(
        title: String,
        category: String,
        content: String,
        submissionId: String
    ): Result<String> {
        val cleanTitle = title.trim()
        val cleanContent = content.trim()
        val wordCount = cleanContent.split(Regex("\\s+")).count { it.isNotBlank() }
        if (cleanTitle.isBlank() || cleanTitle.length > 240) {
            return Result.Error(IllegalArgumentException("Enter an article title of up to 240 characters."))
        }
        if (wordCount < 500) {
            return Result.Error(IllegalArgumentException("Published articles must contain at least 500 words."))
        }

        return try {
            val response = FirebaseFunctions.getInstance("europe-west1")
                .getHttpsCallable("publishStudentArticle")
                .call(
                    mapOf(
                        "title" to cleanTitle,
                        "category" to category.trim().ifBlank { "Student Research" },
                        "content" to cleanContent,
                        "submissionId" to submissionId
                    )
                )
                .await()
            val responseData = response.data as? Map<*, *>
                ?: throw IllegalStateException("The publishing service returned an invalid response.")
            val articleId = responseData["articleId"] as? String
                ?: throw IllegalStateException("The publishing service did not return an article ID.")
            Result.Success(articleId)
        } catch (e: Exception) {
            Result.Error(
                e,
                "Failed to publish article: ${e.localizedMessage ?: "The server did not accept the request."}"
            )
        }
    }

    suspend fun updateArticle(
        articleId: String,
        title: String,
        category: String,
        content: String,
        currentUid: String,
        currentUserEmail: String?
    ): Result<Unit> {
        val targetRef = rtdb.getReference("vault_research/$articleId")
        return try {
            val snapshot = targetRef.get().await()
            val authorUid = snapshot.child("authorUid").getValue(String::class.java)
            val isAdmin = PLATFORM_ADMIN_EMAILS.contains(currentUserEmail?.lowercase() ?: "")

            if (authorUid != currentUid && !isAdmin) {
                return Result.Error(SecurityException("Only the primary author may update this article."))
            }

            val wordCount = content.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.size
            val updates = mapOf(
                "title" to title.trim(),
                "category" to category.trim(),
                "content" to content.trim(),
                "wordCount" to wordCount
            )
            targetRef.updateChildren(updates).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to edit article: ${e.message}")
        }
    }

    suspend fun deleteArticle(
        articleId: String,
        currentUid: String,
        currentUserEmail: String?
    ): Result<Unit> {
        val targetRef = rtdb.getReference("vault_research/$articleId")
        return try {
            val snapshot = targetRef.get().await()
            val authorUid = snapshot.child("authorUid").getValue(String::class.java)
            val isAdmin = PLATFORM_ADMIN_EMAILS.contains(currentUserEmail?.lowercase() ?: "")

            if (authorUid != currentUid && !isAdmin) {
                return Result.Error(SecurityException("You can only delete your own articles."))
            }

            targetRef.removeValue().await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to delete article: ${e.message}")
        }
    }

    /**
     * Checks if the user is authorized to export this article as PDF.
     * Enforces the rule: Users may only export their own eligible articles or works
     * where they are clearly listed as author/collaborator.
     */
    fun canExportArticle(article: Article, currentUid: String): Boolean {
        return article.authorUid == currentUid || article.collaborators.containsKey(currentUid)
    }
}
