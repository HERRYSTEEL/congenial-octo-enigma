package com.lawbynrhste.app.data.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.SetOptions
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.AgreementRecord
import com.lawbynrhste.app.data.model.AlertRecord
import com.lawbynrhste.app.data.model.AuthSessionState
import com.lawbynrhste.app.data.model.PLATFORM_ADMIN_EMAILS
import com.lawbynrhste.app.data.model.UserAccountData
import com.lawbynrhste.app.data.model.UserProfile
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseManager.auth,
    private val rtdb: com.google.firebase.database.FirebaseDatabase = FirebaseManager.database,
    private val firestore: com.google.firebase.firestore.FirebaseFirestore = FirebaseManager.firestore
) {

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    val isPlatformAdmin: Boolean
        get() = PLATFORM_ADMIN_EMAILS.contains(currentUser?.email?.lowercase() ?: "")

    /**
     * Observes authentication state and synchronizes with RTDB user profile in real-time.
     */
    fun observeSessionState(): Flow<AuthSessionState> = callbackFlow {
        val authListener = FirebaseAuth.AuthStateListener { currentAuth ->
            val user = currentAuth.currentUser
            if (user == null) {
                trySend(AuthSessionState(isLoading = false))
            } else {
                val userRef = rtdb.getReference("users/${user.uid}")
                val valueListener = object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val profileSnap = snapshot.child("profile")
                        val profile = UserProfile(
                            name = profileSnap.child("name").getValue(String::class.java) ?: user.email?.substringBefore("@") ?: "User",
                            username = profileSnap.child("username").getValue(String::class.java) ?: "",
                            role = profileSnap.child("occupation").getValue(String::class.java)
                                ?: profileSnap.child("role").getValue(String::class.java)
                                ?: "user",
                            joined = profileSnap.child("joined").getValue(Long::class.java) ?: 0L,
                            photo = profileSnap.child("photo").getValue(String::class.java) ?: "",
                            bio = profileSnap.child("bio").getValue(String::class.java) ?: "",
                            education = profileSnap.child("university").getValue(String::class.java)
                                ?: profileSnap.child("school").getValue(String::class.java)
                                ?: profileSnap.child("education").getValue(String::class.java)
                                ?: "",
                            field = profileSnap.child("fieldOfStudy").getValue(String::class.java)
                                ?: profileSnap.child("specialty").getValue(String::class.java)
                                ?: profileSnap.child("field").getValue(String::class.java)
                                ?: "",
                            status = profileSnap.child("status").getValue(String::class.java) ?: "online",
                            friendCount = profileSnap.child("friendCount").getValue(Int::class.java) ?: 0,
                            verification = profileSnap.child("verification").getValue(String::class.java),
                            showOfficialName = profileSnap.child("showOfficialName").getValue(Boolean::class.java),
                            occupation = profileSnap.child("occupation").getValue(String::class.java) ?: "",
                            highSchool = profileSnap.child("highSchool").getValue(String::class.java) ?: "",
                            college = profileSnap.child("college").getValue(String::class.java) ?: "",
                            university = profileSnap.child("university").getValue(String::class.java)
                                ?: profileSnap.child("school").getValue(String::class.java)
                                ?: "",
                            fieldOfStudy = profileSnap.child("fieldOfStudy").getValue(String::class.java) ?: "",
                            interests = profileSnap.child("interests").getValue(String::class.java) ?: "",
                            socialLinks = profileSnap.child("socialLinks").children.mapNotNull { child ->
                                val key = child.key ?: return@mapNotNull null
                                val value = child.getValue(String::class.java)
                                if (value.isNullOrBlank()) null else key to value
                            }.toMap()
                        )

                        val isFrozen = snapshot.child("isFrozen").getValue(Boolean::class.java) ?: false
                        val alertMessage = snapshot.child("alert/message").getValue(String::class.java)
                        val alert = if (!alertMessage.isNullOrBlank()) AlertRecord(alertMessage) else null

                        val agreementSnap = snapshot.child("agreement")
                        val agreement = if (agreementSnap.exists()) {
                            AgreementRecord(
                                accepted = agreementSnap.child("accepted").getValue(Boolean::class.java) ?: false,
                                timestamp = agreementSnap.child("timestamp").getValue(Long::class.java) ?: 0L
                            )
                        } else null

                        val cookieSnap = snapshot.child("cookiesConsent")
                        val cookiesConsent = if (cookieSnap.exists()) {
                            AgreementRecord(
                                accepted = cookieSnap.child("accepted").getValue(Boolean::class.java) ?: false,
                                timestamp = cookieSnap.child("timestamp").getValue(Long::class.java) ?: 0L
                            )
                        } else null

                        val accountData = UserAccountData(
                            uid = user.uid,
                            email = user.email ?: "",
                            profile = profile,
                            accountType = snapshot.child("accountType").getValue(String::class.java) ?: "standard",
                            isFrozen = isFrozen,
                            alert = alert,
                            agreement = agreement,
                            cookiesConsent = cookiesConsent
                        )

                        val isAdmin = PLATFORM_ADMIN_EMAILS.contains(user.email?.lowercase() ?: "")
                        trySend(
                            AuthSessionState(
                                uid = user.uid,
                                email = user.email,
                                userAccount = accountData,
                                isLoading = false,
                                isPlatformAdmin = isAdmin,
                                isFrozen = isFrozen,
                                pendingAlert = alert?.message
                            )
                        )
                    }

                    override fun onCancelled(error: DatabaseError) {
                        trySend(AuthSessionState(uid = user.uid, email = user.email, isLoading = false))
                    }
                }

                userRef.addValueEventListener(valueListener)
            }
        }

        auth.addAuthStateListener(authListener)
        awaitClose {
            auth.removeAuthStateListener(authListener)
        }
    }

    suspend fun signIn(email: String, pass: String): Result<FirebaseUser> {
        return try {
            val authResult = auth.signInWithEmailAndPassword(email.trim(), pass).await()
            val user = authResult.user ?: throw IllegalStateException("Authentication failed: empty user record")

            // Verify freeze status immediately
            val snapshot = rtdb.getReference("users/${user.uid}/isFrozen").get().await()
            val isFrozen = snapshot.getValue(Boolean::class.java) ?: false
            if (isFrozen) {
                auth.signOut()
                return Result.Error(IllegalStateException("Account is suspended by platform administration."))
            }

            // Sync online status
            rtdb.getReference("users/${user.uid}/status").setValue("online")
            Result.Success(user)
        } catch (e: Exception) {
            Result.Error(e, e.localizedMessage?.replace("Firebase: ", "") ?: "Failed to sign in")
        }
    }

    suspend fun register(
        firstName: String,
        lastName: String,
        username: String,
        email: String,
        pass: String
    ): Result<FirebaseUser> {
        return try {
            val cleanFname = firstName.trim()
            val cleanLname = lastName.trim()
            val cleanUname = username.trim()
            val cleanEmail = email.trim()

            require(cleanFname.isNotBlank() && cleanLname.isNotBlank() && cleanUname.isNotBlank()) {
                "All profile fields are required"
            }

            val authResult = auth.createUserWithEmailAndPassword(cleanEmail, pass).await()
            val user = authResult.user ?: throw IllegalStateException("User creation failed")

            val fullName = "$cleanFname $cleanLname"
            val defaultPhoto = "https://ui-avatars.com/api/?name=${cleanFname}+${cleanLname}&background=d4af37&color=000"

            val initialProfile = mapOf(
                "name" to fullName,
                "username" to cleanUname,
                "role" to "user",
                "joined" to System.currentTimeMillis(),
                "photo" to defaultPhoto,
                "status" to "online"
            )

            val agreement = mapOf(
                "accepted" to true,
                "timestamp" to System.currentTimeMillis()
            )
            rtdb.getReference("users/${user.uid}").updateChildren(
                mapOf(
                    "profile" to initialProfile,
                    "agreement" to agreement
                )
            ).await()

            // Also synchronize in Firestore users/{uid} for Lobby search/mentions
            firestore.collection("users").document(user.uid).set(
                mapOf(
                    "profile" to mapOf(
                        "name" to fullName,
                        "username" to cleanUname,
                        "role" to "user",
                        "photo" to defaultPhoto,
                        "email" to cleanEmail
                    )
                ),
                SetOptions.merge()
            ).await()

            Result.Success(user)
        } catch (e: Exception) {
            Result.Error(e, e.localizedMessage?.replace("Firebase: ", "") ?: "Account registration failed")
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        return try {
            auth.sendPasswordResetEmail(email.trim()).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, e.localizedMessage?.replace("Firebase: ", "") ?: "Failed to send reset email")
        }
    }

    suspend fun saveAgreementConsent(accepted: Boolean): Result<Unit> {
        val uid = currentUser?.uid ?: return Result.Error(IllegalStateException("Not authenticated"))
        return try {
            val record = mapOf("accepted" to accepted, "timestamp" to System.currentTimeMillis())
            rtdb.getReference("users/$uid/agreement").setValue(record).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to save terms agreement")
        }
    }

    suspend fun saveCookiesConsent(accepted: Boolean): Result<Unit> {
        val uid = currentUser?.uid ?: return Result.Error(IllegalStateException("Not authenticated"))
        return try {
            val record = mapOf("accepted" to accepted, "timestamp" to System.currentTimeMillis())
            rtdb.getReference("users/$uid/cookiesConsent").setValue(record).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to save cookie preferences")
        }
    }

    suspend fun clearAlert(): Result<Unit> {
        val uid = currentUser?.uid ?: return Result.Error(IllegalStateException("Not authenticated"))
        return try {
            rtdb.getReference("users/$uid/alert").removeValue().await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to dismiss alert")
        }
    }

    suspend fun signOut() {
        val uid = currentUser?.uid
        if (uid != null) {
            try {
                rtdb.getReference("users/$uid/status").setValue("offline")
            } catch (_: Exception) {}
        }
        auth.signOut()
    }
}
