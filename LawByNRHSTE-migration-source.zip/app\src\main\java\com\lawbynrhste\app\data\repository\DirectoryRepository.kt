package com.lawbynrhste.app.data.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.DirectoryMember
import com.lawbynrhste.app.data.model.UserProfile
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

internal fun DataSnapshot.toUserProfile(): UserProfile =
    UserProfile(
            name = child("name").getValue(String::class.java)
                ?: child("displayName").getValue(String::class.java)
                ?: "Member",
            username = child("username").getValue(String::class.java) ?: "",
            role = child("occupation").getValue(String::class.java)
                ?: child("role").getValue(String::class.java)
                ?: "user",
            photo = child("photo").getValue(String::class.java)
                ?: child("photoURL").getValue(String::class.java)
                ?: child("photoUrl").getValue(String::class.java)
                ?: child("avatar").getValue(String::class.java)
                ?: "",
            bio = child("bio").getValue(String::class.java) ?: "",
            education = child("school").getValue(String::class.java)
                ?: child("college").getValue(String::class.java)
                ?: child("university").getValue(String::class.java)
                ?: "",
            field = child("specialty").getValue(String::class.java)
                ?: child("legalSpecialty").getValue(String::class.java)
                ?: child("fieldOfStudy").getValue(String::class.java)
                ?: "",
            friendCount = child("friendCount").getValue(Int::class.java) ?: 0,
            verification = child("verification").getValue(String::class.java),
            showOfficialName = child("showOfficialName").getValue(Boolean::class.java),
            occupation = child("occupation").getValue(String::class.java) ?: "",
            highSchool = child("highSchool").getValue(String::class.java) ?: "",
            college = child("college").getValue(String::class.java) ?: "",
            university = child("university").getValue(String::class.java)
                ?: child("school").getValue(String::class.java)
                ?: "",
            fieldOfStudy = child("fieldOfStudy").getValue(String::class.java) ?: "",
            interests = child("interests").getValue(String::class.java) ?: "",
            socialLinks = child("socialLinks").children.mapNotNull { link ->
                val key = link.key ?: return@mapNotNull null
                val value = link.getValue(String::class.java)
                if (value.isNullOrBlank()) null else key to value
            }.toMap()
        )

class DirectoryRepository(
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {
    fun observeMembers(currentUid: String): Flow<List<DirectoryMember>> = callbackFlow {
        val profilesRef = rtdb.getReference("public_profiles")
        val followingRef = rtdb.getReference("following/$currentUid")
        val followersRef = rtdb.getReference("followers")
        var profilesSnapshot: DataSnapshot? = null
        var followingSnapshot: DataSnapshot? = null
        var followersSnapshot: DataSnapshot? = null

        fun emitMembers() {
            val profiles = profilesSnapshot ?: return
            val following = followingSnapshot ?: return
            val followers = followersSnapshot ?: return
            val list = profiles.children.mapNotNull { child ->
                val uid = child.key ?: return@mapNotNull null
                if (uid == currentUid) return@mapNotNull null

                val profileSnap = child.child("profile")
                val profile = profileSnap.toUserProfile().copy(
                    status = child.child("status/state").getValue(String::class.java)
                        ?: child.child("status").getValue(String::class.java)
                        ?: "offline"
                )
                DirectoryMember(
                    uid = uid,
                    profile = profile,
                    isFollowing = following.child(uid).exists(),
                    followerCount = followers.child(uid).childrenCount.toInt()
                )
            }
            trySend(list)
        }

        fun listener(onUpdate: (DataSnapshot) -> Unit): ValueEventListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                onUpdate(snapshot)
                emitMembers()
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        val profilesListener = listener { profilesSnapshot = it }
        val followingListener = listener { followingSnapshot = it }
        val followersListener = listener { followersSnapshot = it }
        profilesRef.addValueEventListener(profilesListener)
        followingRef.addValueEventListener(followingListener)
        followersRef.addValueEventListener(followersListener)
        awaitClose {
            profilesRef.removeEventListener(profilesListener)
            followingRef.removeEventListener(followingListener)
            followersRef.removeEventListener(followersListener)
        }
    }

    suspend fun getMemberProfile(uid: String): Result<UserProfile> {
        return try {
            val profilePath = if (FirebaseManager.auth.currentUser?.uid == uid) {
                "users/$uid/profile"
            } else {
                "public_profiles/$uid/profile"
            }
            val snapshot = rtdb.getReference(profilePath).get().await()
            if (!snapshot.exists()) return Result.Error(NoSuchElementException("User profile not found"))

            val followerCount = rtdb.getReference("followers/$uid").get().await().childrenCount.toInt()
            Result.Success(snapshot.toUserProfile().copy(friendCount = followerCount))
        } catch (e: Exception) {
            Result.Error(e, "Failed to load member profile")
        }
    }

    suspend fun updateMyProfile(
        currentUid: String,
        name: String,
        bio: String,
        education: String,
        field: String,
        photoUrl: String?,
        username: String? = null,
        officialName: String? = null,
        showOfficialName: Boolean? = null,
        occupation: String? = null,
        highSchool: String? = null,
        college: String? = null,
        university: String? = null,
        fieldOfStudy: String? = null,
        interests: String? = null,
        socialLinks: Map<String, String>? = null
    ): Result<Unit> {
        return try {
            val cleanUsername = username?.trim().orEmpty()
            val cleanOfficialName = officialName?.trim().orEmpty()
            val publicName = when (showOfficialName) {
                true -> cleanOfficialName.ifBlank { name.trim() }
                false -> cleanUsername.ifBlank { name.trim() }
                null -> name.trim()
            }
            val updates = hashMapOf<String, Any>(
                "name" to publicName,
                "bio" to bio.trim(),
                "education" to education.trim(),
                "field" to field.trim()
            )
            username?.let { updates["username"] = cleanUsername }
            showOfficialName?.let { updates["showOfficialName"] = it }
            occupation?.let { updates["occupation"] = it.trim() }
            highSchool?.let { updates["highSchool"] = it.trim() }
            college?.let { updates["college"] = it.trim() }
            university?.let {
                val cleanUniversity = it.trim()
                updates["university"] = cleanUniversity
                updates["school"] = cleanUniversity.ifBlank {
                    college?.trim().orEmpty().ifBlank { highSchool?.trim().orEmpty() }
                }
            }
            fieldOfStudy?.let {
                updates["fieldOfStudy"] = it.trim()
                updates["field"] = it.trim()
            }
            interests?.let { updates["interests"] = it.trim() }
            socialLinks?.let { links ->
                updates["socialLinks"] = links.mapValues { (_, value) -> value.trim() }
                    .filterValues(String::isNotBlank)
            }
            if (!photoUrl.isNullOrBlank()) {
                updates["photo"] = photoUrl
            }
            val multiPathUpdates = mutableMapOf<String, Any?>()
            updates.forEach { (key, value) ->
                multiPathUpdates["users/$currentUid/profile/$key"] = value
            }
            officialName?.let {
                multiPathUpdates["private_profiles/$currentUid/officialNames"] = cleanOfficialName
            }
            rtdb.reference.updateChildren(multiPathUpdates).await()

            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to update profile: ${e.message}")
        }
    }

    suspend fun getMyOfficialName(currentUid: String): Result<String> {
        return try {
            val snapshot = rtdb.getReference("private_profiles/$currentUid/officialNames").get().await()
            Result.Success(snapshot.getValue(String::class.java).orEmpty())
        } catch (e: Exception) {
            Result.Error(e, "Failed to load your private profile details")
        }
    }

    suspend fun toggleFollow(
        currentUid: String,
        targetUid: String,
        senderName: String,
        isFollowing: Boolean
    ): Result<Unit> {
        if (currentUid == targetUid) {
            return Result.Error(IllegalArgumentException("You cannot follow your own profile."))
        }
        return try {
            val timestamp = System.currentTimeMillis()
            val updates = hashMapOf<String, Any?>(
                "following/$currentUid/$targetUid" to if (isFollowing) null else true,
                "followers/$targetUid/$currentUid" to if (isFollowing) null else true
            )
            if (!isFollowing) {
                val notificationId = rtdb.getReference("notifications/$targetUid").push().key
                    ?: throw IllegalStateException("Could not create a follower notification ID.")
                updates["notifications/$targetUid/$notificationId"] = mapOf(
                    "title" to "New follower",
                    "body" to "$senderName started following you.",
                    "type" to "new-follower",
                    "fromUid" to currentUid,
                    "timestamp" to timestamp,
                    "read" to false
                )
            }
            rtdb.reference.updateChildren(updates).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to update follow relationship: ${e.message}")
        }
    }
}
