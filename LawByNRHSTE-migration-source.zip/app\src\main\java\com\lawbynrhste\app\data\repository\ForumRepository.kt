package com.lawbynrhste.app.data.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.ForumDiscussion
import com.lawbynrhste.app.data.model.ForumReply
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ForumRepository(
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {
    fun observeDiscussions(): Flow<List<ForumDiscussion>> = callbackFlow {
        val discussionsRef = rtdb.getReference("community_discussions")
            .orderByChild("createdAt")
            .limitToLast(50)

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val discussions = snapshot.children.mapNotNull { child ->
                    val id = child.key ?: return@mapNotNull null
                    val replies = child.child("replies").children.mapNotNull { reply ->
                        val replyId = reply.key ?: return@mapNotNull null
                        ForumReply(
                            id = replyId,
                            uid = reply.child("uid").getValue(String::class.java) ?: "",
                            authorName = reply.child("authorName").getValue(String::class.java) ?: "Member",
                            body = reply.child("body").getValue(String::class.java) ?: "",
                            timestamp = reply.child("timestamp").getValue(Long::class.java) ?: 0L
                        )
                    }.sortedBy { it.timestamp }

                    ForumDiscussion(
                        id = id,
                        authorUid = child.child("authorUid").getValue(String::class.java) ?: "",
                        authorName = child.child("authorName").getValue(String::class.java) ?: "Member",
                        title = child.child("title").getValue(String::class.java) ?: "",
                        body = child.child("body").getValue(String::class.java) ?: "",
                        createdAt = child.child("createdAt").getValue(Long::class.java) ?: 0L,
                        replies = replies
                    )
                }.filter { it.title.isNotBlank() && it.body.isNotBlank() }
                    .sortedByDescending { it.createdAt }

                trySend(discussions)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        discussionsRef.addValueEventListener(listener)
        awaitClose { discussionsRef.removeEventListener(listener) }
    }

    suspend fun createDiscussion(
        title: String,
        body: String,
        currentUid: String,
        authorName: String
    ): Result<Unit> {
        val cleanTitle = title.trim()
        val cleanBody = body.trim()
        if (cleanTitle.isBlank() || cleanTitle.length > 120) {
            return Result.Error(IllegalArgumentException("Enter a topic title of up to 120 characters."))
        }
        if (cleanBody.isBlank() || cleanBody.length > 1000) {
            return Result.Error(IllegalArgumentException("Enter a discussion message of up to 1,000 characters."))
        }

        return try {
            val topicRef = rtdb.getReference("community_discussions").push()
            topicRef.setValue(
                mapOf(
                    "authorUid" to currentUid,
                    "authorName" to authorName,
                    "title" to cleanTitle,
                    "body" to cleanBody,
                    "createdAt" to ServerValue.TIMESTAMP,
                    "replies" to emptyMap<String, Any>()
                )
            ).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Could not post discussion: ${e.localizedMessage ?: "The server rejected the request."}")
        }
    }

    suspend fun replyToDiscussion(
        discussion: ForumDiscussion,
        body: String,
        currentUid: String,
        authorName: String
    ): Result<Unit> {
        val cleanBody = body.trim()
        if (cleanBody.isBlank() || cleanBody.length > 500) {
            return Result.Error(IllegalArgumentException("Enter a reply of up to 500 characters."))
        }

        return try {
            val replyRef = rtdb.getReference("community_discussions/${discussion.id}/replies").push()
            replyRef.setValue(
                mapOf(
                    "uid" to currentUid,
                    "authorName" to authorName,
                    "body" to cleanBody,
                    "timestamp" to ServerValue.TIMESTAMP
                )
            ).await()

            if (discussion.authorUid.isNotBlank() && discussion.authorUid != currentUid) {
                try {
                    val notificationRef = rtdb.getReference("notifications/${discussion.authorUid}").push()
                    notificationRef.setValue(
                        mapOf(
                            "title" to "New discussion reply",
                            "body" to "$authorName replied to “${discussion.title}”.",
                            "type" to "forum-reply",
                            "fromUid" to currentUid,
                            "timestamp" to ServerValue.TIMESTAMP,
                            "read" to false
                        )
                    ).await()
                } catch (e: Exception) {
                    return Result.Error(e, "Your reply was posted, but its notification could not be sent.")
                }
            }
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Could not reply to discussion: ${e.localizedMessage ?: "The server rejected the request."}")
        }
    }
}
