package com.lawbynrhste.app.data.repository

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.PLATFORM_ADMIN_EMAILS
import com.lawbynrhste.app.data.model.Post
import com.lawbynrhste.app.data.model.PostComment
import com.lawbynrhste.app.data.model.PostLike
import com.lawbynrhste.app.data.model.PostReply
import com.lawbynrhste.app.data.model.SUPPORTED_REACTIONS
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class LobbyRepository(
    private val firestore: FirebaseFirestore = FirebaseManager.firestore,
    private val rtdb: com.google.firebase.database.FirebaseDatabase = FirebaseManager.database
) {

    /**
     * Observes real-time posts feed from Firestore with targeted query limit to avoid
     * downloading excessive data.
     */
    fun observePosts(limitCount: Long = 50): Flow<List<Post>> = callbackFlow {
        val query = firestore.collection("posts")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(limitCount)

        val listenerRegistration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }

            val posts = snapshot?.documents?.mapNotNull { doc ->
                val isDeleted = doc.getBoolean("deleted") ?: false
                val isHidden = doc.getBoolean("moderationHidden") ?: false
                if (isDeleted || isHidden) return@mapNotNull null

                val mentionsList = doc.get("mentions") as? List<*> ?: emptyList<Any>()
                Post(
                    id = doc.id,
                    uid = doc.getString("uid") ?: "",
                    author = doc.getString("author") ?: "Counsel",
                    avatar = doc.getString("avatar") ?: "",
                    text = doc.getString("text") ?: "",
                    mentions = mentionsList.mapNotNull { it?.toString() },
                    image = doc.getString("image"),
                    sharedFrom = doc.getString("sharedFrom"),
                    sharedFromUid = doc.getString("sharedFromUid"),
                    sharedFromAuthor = doc.getString("sharedFromAuthor"),
                    timestamp = doc.getTimestamp("timestamp"),
                    deleted = false
                )
            } ?: emptyList()

            trySend(posts)
        }

        awaitClose {
            listenerRegistration.remove()
        }
    }

    /**
     * Observes reactions/likes on a single post in real time.
     */
    fun observePostLikes(postId: String): Flow<List<PostLike>> = callbackFlow {
        val listener = firestore.collection("posts").document(postId)
            .collection("likes")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                close(error)
                    return@addSnapshotListener
                }
                val likes = snapshot?.documents?.mapNotNull { doc ->
                    PostLike(
                        uid = doc.id,
                        emoji = doc.getString("emoji") ?: "👍",
                        timestamp = doc.getTimestamp("timestamp")
                    )
                } ?: emptyList()
                trySend(likes)
            }
        awaitClose { listener.remove() }
    }

    /**
     * Observes comments on a post in real time.
     */
    fun observePostComments(postId: String): Flow<List<PostComment>> = callbackFlow {
        val listener = firestore.collection("posts").document(postId)
            .collection("comments")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val comments = snapshot?.documents?.mapNotNull { doc ->
                    if (doc.getBoolean("deleted") == true || doc.getBoolean("moderationHidden") == true) {
                        return@mapNotNull null
                    }
                    PostComment(
                        id = doc.id,
                        uid = doc.getString("uid") ?: "",
                        author = doc.getString("author") ?: "User",
                        text = doc.getString("text") ?: "",
                        timestamp = doc.getTimestamp("timestamp")
                    )
                } ?: emptyList()
                trySend(comments)
            }
        awaitClose { listener.remove() }
    }

    /**
     * Observes threaded replies to a comment in real time.
     */
    fun observeCommentReplies(postId: String, commentId: String): Flow<List<PostReply>> = callbackFlow {
        val listener = firestore.collection("posts").document(postId)
            .collection("comments").document(commentId)
            .collection("replies")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val replies = snapshot?.documents?.mapNotNull { doc ->
                    PostReply(
                        id = doc.id,
                        uid = doc.getString("uid") ?: "",
                        author = doc.getString("author") ?: "User",
                        text = doc.getString("text") ?: "",
                        timestamp = doc.getTimestamp("timestamp")
                    )
                } ?: emptyList()
                trySend(replies)
            }
        awaitClose { listener.remove() }
    }

    suspend fun createPost(
        text: String,
        currentUserUid: String,
        authorName: String,
        authorAvatar: String,
        image: String? = null
    ): Result<String> {
        val cleanText = text.trim()
        if (cleanText.isBlank()) return Result.Error(IllegalArgumentException("Post content cannot be empty"))

        // Extract mentions (@handle)
        val regex = Regex("""@([a-zA-Z0-9_.-]+)""")
        val mentions = regex.findAll(cleanText).map { it.groupValues[1] }.distinct().toList()

        val postData = hashMapOf(
            "uid" to currentUserUid,
            "author" to authorName,
            "avatar" to authorAvatar,
            "text" to cleanText,
            "mentions" to mentions,
            "timestamp" to FieldValue.serverTimestamp()
        )
        if (!image.isNullOrBlank()) {
            postData["image"] = image
        }

        return try {
            val docRef = firestore.collection("posts").add(postData).await()
            Result.Success(docRef.id)
        } catch (e: Exception) {
            Result.Error(e, "Failed to publish post: ${e.message}")
        }
    }

    suspend fun repost(
        originalPost: Post,
        currentUserUid: String,
        authorName: String,
        authorAvatar: String
    ): Result<String> {
        val sourceId = originalPost.sharedFrom ?: originalPost.id
        val postData = hashMapOf(
            "uid" to currentUserUid,
            "author" to authorName,
            "avatar" to authorAvatar,
            "text" to originalPost.text,
            "image" to (originalPost.image ?: null),
            "sharedFrom" to sourceId,
            "sharedFromUid" to (originalPost.sharedFromUid ?: originalPost.uid),
            "sharedFromAuthor" to (originalPost.sharedFromAuthor ?: originalPost.author),
            "timestamp" to FieldValue.serverTimestamp()
        )

        return try {
            val docRef = firestore.collection("posts").add(postData).await()
            notifyUser(
                recipientUid = originalPost.uid,
                fromUid = currentUserUid,
                title = "Post shared",
                body = "$authorName shared your legal post.",
                type = "post-share",
                postId = sourceId
            )
            Result.Success(docRef.id)
        } catch (e: Exception) {
            Result.Error(e, "Failed to repost: ${e.message}")
        }
    }

    suspend fun toggleLike(
        postId: String,
        userId: String,
        emoji: String = "👍",
        postAuthorUid: String?,
        currentUserName: String
    ): Result<Unit> {
        require(SUPPORTED_REACTIONS.contains(emoji)) { "Unsupported emoji reaction: $emoji" }
        val likeDocRef = firestore.collection("posts").document(postId)
            .collection("likes").document(userId)

        return try {
            val existing = likeDocRef.get().await()
            if (existing.exists()) {
                val currentEmoji = existing.getString("emoji")
                if (currentEmoji == emoji) {
                    likeDocRef.delete().await()
                } else {
                    likeDocRef.set(
                        mapOf(
                            "uid" to userId,
                            "emoji" to emoji,
                            "timestamp" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            } else {
                likeDocRef.set(
                    mapOf(
                        "uid" to userId,
                        "emoji" to emoji,
                        "timestamp" to FieldValue.serverTimestamp()
                    )
                ).await()

                if (!postAuthorUid.isNullOrBlank() && postAuthorUid != userId) {
                    notifyUser(
                        recipientUid = postAuthorUid,
                        fromUid = userId,
                        title = "New reaction",
                        body = "$currentUserName reacted $emoji to your post.",
                        type = "post-reaction",
                        postId = postId
                    )
                }
            }
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to apply reaction: ${e.message}")
        }
    }

    suspend fun addComment(
        postId: String,
        text: String,
        currentUserUid: String,
        authorName: String,
        postAuthorUid: String?
    ): Result<String> {
        val cleanText = text.trim()
        if (cleanText.isBlank()) return Result.Error(IllegalArgumentException("Comment cannot be empty"))
        if (cleanText.length > 2000) return Result.Error(IllegalArgumentException("Comment exceeds 2000 characters limit"))

        val commentData = mapOf(
            "uid" to currentUserUid,
            "author" to authorName,
            "text" to cleanText,
            "timestamp" to FieldValue.serverTimestamp()
        )

        return try {
            val docRef = firestore.collection("posts").document(postId)
                .collection("comments").add(commentData).await()

            if (!postAuthorUid.isNullOrBlank() && postAuthorUid != currentUserUid) {
                notifyUser(
                    recipientUid = postAuthorUid,
                    fromUid = currentUserUid,
                    title = "New comment",
                    body = "$authorName commented on your post.",
                    type = "post-comment",
                    postId = postId
                )
            }

            Result.Success(docRef.id)
        } catch (e: Exception) {
            Result.Error(e, "Failed to add comment: ${e.message}")
        }
    }

    suspend fun addReply(
        postId: String,
        commentId: String,
        text: String,
        currentUserUid: String,
        authorName: String,
        commentAuthorUid: String?,
        postAuthorUid: String?
    ): Result<String> {
        val cleanText = text.trim()
        if (cleanText.isBlank()) return Result.Error(IllegalArgumentException("Reply cannot be empty"))
        if (cleanText.length > 1000) return Result.Error(IllegalArgumentException("Reply exceeds 1000 characters limit"))

        val replyData = mapOf(
            "uid" to currentUserUid,
            "author" to authorName,
            "text" to cleanText,
            "timestamp" to FieldValue.serverTimestamp()
        )

        return try {
            val docRef = firestore.collection("posts").document(postId)
                .collection("comments").document(commentId)
                .collection("replies").add(replyData).await()

            val recipients = setOfNotNull(commentAuthorUid, postAuthorUid).filter { it != currentUserUid }
            for (recipientUid in recipients) {
                notifyUser(
                    recipientUid = recipientUid,
                    fromUid = currentUserUid,
                    title = "New reply",
                    body = "$authorName replied to a comment.",
                    type = "comment-reply",
                    postId = postId
                )
            }

            Result.Success(docRef.id)
        } catch (e: Exception) {
            Result.Error(e, "Failed to add reply: ${e.message}")
        }
    }

    suspend fun deletePost(
        post: Post,
        currentUid: String,
        currentUserEmail: String?
    ): Result<Unit> {
        val isAdmin = PLATFORM_ADMIN_EMAILS.contains(currentUserEmail?.lowercase() ?: "")
        if (post.uid != currentUid && !isAdmin) {
            return Result.Error(SecurityException("Unauthorized: You may only delete your own content."))
        }

        return try {
            firestore.collection("posts").document(post.id).delete().await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to delete post: ${e.message}")
        }
    }

    private suspend fun notifyUser(
        recipientUid: String,
        fromUid: String,
        title: String,
        body: String,
        type: String,
        postId: String
    ) {
        if (recipientUid.isBlank() || recipientUid == fromUid) return
        try {
            val notifRef = rtdb.getReference("notifications/$recipientUid").push()
            val notificationData = mapOf(
                "title" to title,
                "body" to body,
                "type" to type,
                "fromUid" to fromUid,
                "postId" to postId,
                "timestamp" to System.currentTimeMillis(),
                "read" to false
            )
            notifRef.setValue(notificationData).await()
        } catch (e: Exception) {
            android.util.Log.w("LobbyRepository", "Could not send notification to $recipientUid", e)
        }
    }
}
