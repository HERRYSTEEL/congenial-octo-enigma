package com.lawbynrhste.app.data.repository

import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import com.lawbynrhste.app.core.IdGenerator
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.ConversationOverview
import com.lawbynrhste.app.data.model.DeliveryStatus
import com.lawbynrhste.app.data.model.OutgoingMessageDraft
import com.lawbynrhste.app.data.model.PrivateMessage
import com.lawbynrhste.app.data.model.ReplyReference
import com.lawbynrhste.app.data.model.UserProfile
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.concurrent.ConcurrentHashMap

class MessagingRepository(
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {
    companion object {
        private const val TAG = "MessagingRepository"
    }

    // In-memory queue of pending message drafts indexed by stable ID to ensure true idempotency
    private val pendingDrafts = ConcurrentHashMap<String, OutgoingMessageDraft>()

    // Concurrency send locks per room to prevent rapid multi-taps
    private val roomSendLocks = ConcurrentHashMap<String, Boolean>()

    /**
     * Observes real-time messages for an active room.
     * Enforces exactly one live listener per room and unregisters when navigation leaves.
     */
    fun observeMessages(roomPath: String, currentUid: String): Flow<List<PrivateMessage>> = callbackFlow {
        val messagesRef = rtdb.getReference("private_messages/$roomPath")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val messages = mutableListOf<PrivateMessage>()
                for (child in snapshot.children) {
                    val key = child.key ?: continue
                    val sender = child.child("sender").getValue(String::class.java) ?: ""

                    // Check deletion flags
                    val isDeletedForAll = child.child("deleted").getValue(Boolean::class.java) ?: false
                    val deletedForMe = child.child("deletedFor/$currentUid").getValue(Boolean::class.java) ?: false
                    if (deletedForMe) continue

                    val replyToSnap = child.child("replyTo")
                    val replyTo = if (replyToSnap.exists()) {
                        ReplyReference(
                            key = replyToSnap.child("key").getValue(String::class.java) ?: "",
                            sender = replyToSnap.child("sender").getValue(String::class.java) ?: "",
                            text = replyToSnap.child("text").getValue(String::class.java) ?: "",
                            type = replyToSnap.child("type").getValue(String::class.java) ?: "text"
                        )
                    } else null

                    val delivered = child.child("delivered").getValue(Boolean::class.java) ?: false
                    val seen = child.child("seen").getValue(Boolean::class.java) ?: false
                    val timestamp = child.child("timestamp").getValue(Long::class.java) ?: 0L

                    // Automatically update delivery/seen state for incoming messages
                    if (sender != currentUid) {
                        if (!delivered) {
                            rtdb.getReference("private_messages/$roomPath/$key/delivered").setValue(true)
                        }
                        if (!seen) {
                            rtdb.getReference("private_messages/$roomPath/$key/seen").setValue(true)
                        }
                    }

                    val msg = PrivateMessage(
                        id = key,
                        sender = sender,
                        text = if (isDeletedForAll) "This message was deleted" else child.child("text").getValue(String::class.java),
                        type = child.child("type").getValue(String::class.java) ?: "text",
                        fileUrl = child.child("fileUrl").getValue(String::class.java),
                        fileName = child.child("fileName").getValue(String::class.java),
                        mimeType = child.child("mimeType").getValue(String::class.java),
                        duration = child.child("duration").getValue(Int::class.java),
                        statusOwner = child.child("statusOwner").getValue(String::class.java),
                        statusId = child.child("statusId").getValue(String::class.java),
                        replyTo = replyTo,
                        delivered = delivered,
                        seen = seen,
                        timestamp = timestamp,
                        deleted = isDeletedForAll,
                        localStatus = if (seen) DeliveryStatus.SEEN else if (delivered) DeliveryStatus.DELIVERED else DeliveryStatus.SENT
                    )
                    messages.add(msg)
                }

                messages.sortBy { it.timestamp }
                trySend(messages)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Failed reading room $roomPath: ${error.message}")
                close(error.toException())
            }
        }

        messagesRef.addValueEventListener(listener)
        awaitClose {
            messagesRef.removeEventListener(listener)
        }
    }

    /**
     * Observes conversations overview list under private_messages_overview/{currentUid}.
     */
    fun observeInboxOverviews(currentUid: String): Flow<List<ConversationOverview>> = callbackFlow {
        val overviewRef = rtdb.getReference("private_messages_overview/$currentUid")
        var overviewSnapshot: DataSnapshot? = null
        val profilesByUid = mutableMapOf<String, UserProfile>()
        val profileListeners = mutableMapOf<String, Pair<DatabaseReference, ValueEventListener>>()

        fun emitConversations() {
            val overviews = overviewSnapshot ?: return
            val list = overviews.children.mapNotNull { child ->
                val otherUid = child.key ?: return@mapNotNull null
                ConversationOverview(
                    otherUid = otherUid,
                    preview = child.child("preview").getValue(String::class.java) ?: "",
                    sender = child.child("sender").getValue(String::class.java) ?: "",
                    timestamp = child.child("timestamp").getValue(Long::class.java) ?: 0L,
                    unread = child.child("unread").getValue(Boolean::class.java) ?: false,
                    otherUser = profilesByUid[otherUid]
                )
            }.sortedByDescending { it.timestamp }
            trySend(list)
        }

        fun syncProfileListeners(snapshot: DataSnapshot) {
            val conversationUids = snapshot.children.mapNotNull { it.key }.toSet()
            (profileListeners.keys - conversationUids).forEach { uid ->
                val (reference, listener) = profileListeners.remove(uid) ?: return@forEach
                reference.removeEventListener(listener)
                profilesByUid.remove(uid)
            }

            conversationUids.forEach { uid ->
                if (uid in profileListeners) return@forEach

                val reference = rtdb.getReference("public_profiles/$uid")
                val listener = object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val profileSnapshot = snapshot.child("profile")
                        if (profileSnapshot.exists()) {
                            profilesByUid[uid] = profileSnapshot.toUserProfile().copy(
                                status = snapshot.child("status/state").getValue(String::class.java)
                                    ?: snapshot.child("status").getValue(String::class.java)
                                    ?: "offline"
                            )
                        } else {
                            profilesByUid.remove(uid)
                        }
                        emitConversations()
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.w(TAG, "Failed reading inbox profile $uid: ${error.message}")
                        profilesByUid.remove(uid)
                        emitConversations()
                    }
                }
                profileListeners[uid] = reference to listener
                reference.addValueEventListener(listener)
            }
        }

        val overviewListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                overviewSnapshot = snapshot
                syncProfileListeners(snapshot)
                emitConversations()
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        overviewRef.addValueEventListener(overviewListener)
        awaitClose {
            overviewRef.removeEventListener(overviewListener)
            profileListeners.values.forEach { (reference, listener) ->
                reference.removeEventListener(listener)
            }
        }
    }

    /**
     * Marks an inbox conversation as read.
     */
    suspend fun markInboxRead(currentUid: String, otherUid: String) {
        try {
            rtdb.getReference("private_messages_overview/$currentUid/$otherUid/unread").setValue(false).await()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to mark inbox read for $otherUid", e)
        }
    }

    /**
     * Creates a stable message draft before attempting any write.
     * This provides the single source of truth for retries without duplicate push() creation.
     */
    fun prepareDraft(
        currentUid: String,
        recipientUid: String,
        text: String? = null,
        type: String = "text",
        fileUrl: String? = null,
        fileName: String? = null,
        mimeType: String? = null,
        duration: Int? = null,
        statusOwner: String? = null,
        statusId: String? = null,
        replyTo: ReplyReference? = null
    ): OutgoingMessageDraft {
        val stableId = IdGenerator.createStableMessageId()
        val roomPath = IdGenerator.canonicalRoomId(currentUid, recipientUid)

        val message = PrivateMessage(
            id = stableId,
            sender = currentUid,
            text = text,
            type = type,
            fileUrl = fileUrl,
            fileName = fileName,
            mimeType = mimeType,
            duration = duration,
            statusOwner = statusOwner,
            statusId = statusId,
            replyTo = replyTo,
            delivered = false,
            seen = false,
            timestamp = System.currentTimeMillis(),
            localStatus = DeliveryStatus.PENDING
        )

        val draft = OutgoingMessageDraft(
            stableId = stableId,
            roomPath = roomPath,
            recipientUid = recipientUid,
            message = message
        )
        pendingDrafts[stableId] = draft
        return draft
    }

    /**
     * Sends or retries an outgoing message draft with strict idempotency.
     * Reuses the exact stable ID and checks the database before writing if a retry is triggered.
     */
    suspend fun sendMessage(draft: OutgoingMessageDraft): Result<PrivateMessage> {
        val lockKey = draft.roomPath
        if (roomSendLocks[lockKey] == true) {
            return Result.Error(IllegalStateException("A message send is currently in progress for this conversation."))
        }

        roomSendLocks[lockKey] = true
        val targetRef = rtdb.getReference("private_messages/${draft.roomPath}/${draft.stableId}")

        try {
            // First check if the record was already written in a prior attempt that experienced network uncertainty
            val existingSnap = targetRef.get().await()
            var messageSaved = false

            if (existingSnap.exists() && existingSnap.child("sender").getValue(String::class.java) == draft.message.sender) {
                messageSaved = true
                Log.i(TAG, "Message with stable ID ${draft.stableId} already confirmed in database; skipping re-write.")
            } else {
                val payload = hashMapOf<String, Any>(
                    "sender" to draft.message.sender,
                    "type" to draft.message.type,
                    "delivered" to false,
                    "seen" to false,
                    "timestamp" to ServerValue.TIMESTAMP
                )
                draft.message.text?.let { payload["text"] = it }
                draft.message.fileUrl?.let { payload["fileUrl"] = it }
                draft.message.fileName?.let { payload["fileName"] = it }
                draft.message.mimeType?.let { payload["mimeType"] = it }
                draft.message.duration?.let { payload["duration"] = it }
                draft.message.statusOwner?.let { payload["statusOwner"] = it }
                draft.message.statusId?.let { payload["statusId"] = it }
                draft.message.replyTo?.let {
                    payload["replyTo"] = mapOf(
                        "key" to it.key,
                        "sender" to it.sender,
                        "text" to it.text,
                        "type" to it.type
                    )
                }

                targetRef.setValue(payload).await()
                messageSaved = true
            }

            // Sync inbox overview for both users
            if (messageSaved) {
                val preview = when (draft.message.type) {
                    "image" -> "[Photo]"
                    "voice" -> "[Voice Message]"
                    "file" -> "[File: ${draft.message.fileName ?: "Document"}]"
                    "status_reply" -> "[Reply to update: ${draft.message.text?.take(30) ?: ""}]"
                    else -> draft.message.text?.take(60) ?: "[Message]"
                }
                syncInboxOverview(
                    currentUid = draft.message.sender,
                    recipientUid = draft.recipientUid,
                    preview = preview,
                    roomPath = draft.roomPath
                )
            }

            pendingDrafts.remove(draft.stableId)
            return Result.Success(draft.message.copy(localStatus = DeliveryStatus.SENT))
        } catch (e: Exception) {
            Log.w(TAG, "Message send encountered uncertainty: ${e.message}")
            // Check once more to verify if it reached the server despite the exception
            try {
                val checkSnap = targetRef.get().await()
                if (checkSnap.exists()) {
                    pendingDrafts.remove(draft.stableId)
                    return Result.Success(draft.message.copy(localStatus = DeliveryStatus.SENT))
                }
            } catch (_: Exception) {}

            return Result.Error(e, "Could not confirm message delivery: ${e.message}. Retrying will safely reuse this message record.")
        } finally {
            roomSendLocks.remove(lockKey)
        }
    }

    /**
     * Updates inbox overview without duplicating message records.
     */
    private suspend fun syncInboxOverview(
        currentUid: String,
        recipientUid: String,
        preview: String,
        roomPath: String
    ) {
        try {
            val timestamp = System.currentTimeMillis()
            val updates = hashMapOf<String, Any>(
                "private_messages_overview/$currentUid/$recipientUid" to mapOf(
                    "preview" to preview,
                    "sender" to currentUid,
                    "timestamp" to timestamp,
                    "unread" to false
                ),
                "private_messages_overview/$recipientUid/$currentUid" to mapOf(
                    "preview" to preview,
                    "sender" to currentUid,
                    "timestamp" to timestamp,
                    "unread" to true
                )
            )
            rtdb.reference.updateChildren(updates).await()
        } catch (e: Exception) {
            Log.w(TAG, "Inbox overview preview sync failed (message itself was already confirmed): ${e.message}")
        }
    }

    suspend fun deleteForMe(roomPath: String, messageId: String, currentUid: String): Result<Unit> {
        return try {
            rtdb.getReference("private_messages/$roomPath/$messageId/deletedFor/$currentUid").setValue(true).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to delete message for you: ${e.message}")
        }
    }

    suspend fun deleteForEveryone(roomPath: String, messageId: String, currentUid: String): Result<Unit> {
        val targetRef = rtdb.getReference("private_messages/$roomPath/$messageId")
        return try {
            val snapshot = targetRef.get().await()
            val sender = snapshot.child("sender").getValue(String::class.java)
            if (sender != currentUid) {
                return Result.Error(SecurityException("You can only delete messages sent by your account."))
            }

            val updates = mapOf(
                "deleted" to true,
                "text" to "This message was deleted",
                "type" to "text",
                "fileUrl" to null,
                "fileName" to null
            )
            targetRef.updateChildren(updates).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to delete message for everyone: ${e.message}")
        }
    }
}
