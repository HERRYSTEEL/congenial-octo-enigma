package com.lawbynrhste.app.data.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.AdminSupportMessage
import com.lawbynrhste.app.data.model.NotificationItem
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class NotificationsRepository(
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {

    fun observeNotifications(currentUid: String): Flow<List<NotificationItem>> = callbackFlow {
        val ref = rtdb.getReference("notifications/$currentUid")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<NotificationItem>()
                for (child in snapshot.children) {
                    val id = child.key ?: continue
                    val title = child.child("title").getValue(String::class.java) ?: "Notice"
                    val body = child.child("body").getValue(String::class.java) ?: ""
                    val type = child.child("type").getValue(String::class.java) ?: "general"
                    val fromUid = child.child("fromUid").getValue(String::class.java)
                    val postId = child.child("postId").getValue(String::class.java)
                    val timestamp = child.child("timestamp").getValue(Long::class.java) ?: 0L
                    val read = child.child("read").getValue(Boolean::class.java) ?: false

                    list.add(
                        NotificationItem(
                            id = id,
                            title = title,
                            body = body,
                            type = type,
                            fromUid = fromUid,
                            postId = postId,
                            timestamp = timestamp,
                            read = read
                        )
                    )
                }
                list.sortByDescending { it.timestamp }
                trySend(list)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        ref.addValueEventListener(listener)
        awaitClose {
            ref.removeEventListener(listener)
        }
    }

    fun observeSupportMessages(currentUid: String): Flow<List<AdminSupportMessage>> = callbackFlow {
        val ref = rtdb.getReference("admin_support/$currentUid")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<AdminSupportMessage>()
                for (child in snapshot.children) {
                    val id = child.key ?: continue
                    val from = child.child("from").getValue(String::class.java) ?: "Admin"
                    val text = child.child("text").getValue(String::class.java) ?: ""
                    val timestamp = child.child("timestamp").getValue(Long::class.java) ?: 0L
                    val unread = child.child("unread").getValue(Boolean::class.java) ?: false
                    val anonymous = child.child("anonymous").getValue(Boolean::class.java) ?: false

                    list.add(
                        AdminSupportMessage(
                            id = id,
                            from = from,
                            text = text,
                            timestamp = timestamp,
                            unread = unread,
                            anonymous = anonymous
                        )
                    )
                }
                list.sortByDescending { it.timestamp }
                trySend(list)
            }

            override fun onCancelled(error: DatabaseError) {
                trySend(emptyList())
            }
        }

        ref.addValueEventListener(listener)
        awaitClose {
            ref.removeEventListener(listener)
        }
    }

    suspend fun markNotificationRead(currentUid: String, notifId: String): Result<Unit> {
        return try {
            rtdb.getReference("notifications/$currentUid/$notifId/read").setValue(true).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to mark notification read")
        }
    }

    suspend fun markSupportRead(currentUid: String, supportId: String): Result<Unit> {
        return try {
            rtdb.getReference("admin_support/$currentUid/$supportId/unread").setValue(false).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to mark support message read")
        }
    }
}

