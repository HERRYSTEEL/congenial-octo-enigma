package com.lawbynrhste.app.data.repository

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.CuratedLegalResource
import com.lawbynrhste.app.data.model.LegalNewsItem
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.text.DateFormat
import java.util.Date

class ResourcesRepository(
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {

    /**
     * Curated South African legal databases and court repositories from resources.html.
     */
    val curatedResources: List<CuratedLegalResource> = listOf(
        CuratedLegalResource(
            title = "Constitutional Court of SA",
            description = "Direct access to Constitutional Court judgments, case summaries, and landmark constitutional law decisions from South Africa's highest court.",
            url = "https://www.concourt.org.za/",
            iconName = "landmark",
            category = "Constitutional Law"
        ),
        CuratedLegalResource(
            title = "SAFLII Database",
            description = "South African Free Law Initiative - comprehensive database of SA court decisions, legislation, and legal documents. Largest free legal database in Africa.",
            url = "https://www.saflii.org/",
            iconName = "book_open",
            category = "Legal Research"
        ),
        CuratedLegalResource(
            title = "Jutas Online",
            description = "Jutas legal reports and case law library. Access annotated case reports, legal journals, and commentary on South African law.",
            url = "https://www.jutas.com/",
            iconName = "gavel",
            category = "Corporate Law"
        ),
        CuratedLegalResource(
            title = "Government Gazette",
            description = "Official Government Gazette repository. Access proclamations, legislation, notices, and all official government publications.",
            url = "https://www.gov.za/documents/government-gazette",
            iconName = "scroll",
            category = "Legislation"
        ),
        CuratedLegalResource(
            title = "Supreme Court of Appeal",
            description = "South African Supreme Court of Appeal judgments and case law. Access detailed judicial decisions and legal precedents.",
            url = "https://www.sca.org.za/",
            iconName = "court",
            category = "Criminal Justice"
        )
    )

    /**
     * Observes live legal news from RTDB 'legal_news'.
     * If the database has no records (e.g. because scheduled Cloud Function RSS importer is not deployed),
     * delivers an empty list honestly without fabricating data.
     */
    fun observeLiveLegalNews(): Flow<List<LegalNewsItem>> = callbackFlow {
        val newsRef = rtdb.getReference("legal_news/items")

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<LegalNewsItem>()
                for (child in snapshot.children) {
                    val id = child.key ?: continue
                    val title = child.child("title").getValue(String::class.java) ?: ""
                    val summary = child.child("summary").getValue(String::class.java) ?: ""
                    val publishedAt = child.child("publishedAt").getValue(Long::class.java) ?: 0L
                    val source = child.child("source").getValue(String::class.java) ?: ""
                    val link = child.child("url").getValue(String::class.java) ?: ""
                    val category = child.child("categories").children
                        .firstOrNull()
                        ?.getValue(String::class.java)
                        ?.replace('-', ' ')
                        ?.split(' ')
                        ?.joinToString(" ") { word -> word.replaceFirstChar { it.uppercase() } }
                        ?: "Constitutional Law"

                    if (title.isNotBlank()) {
                        list.add(
                            LegalNewsItem(
                                id = id,
                                title = title,
                                summary = summary,
                                date = if (publishedAt > 0) {
                                    DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(publishedAt))
                                } else "",
                                source = source,
                                link = link,
                                category = category,
                                timestamp = publishedAt
                            )
                        )
                    }
                }
                list.sortByDescending { it.timestamp }
                trySend(list)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        newsRef.addValueEventListener(listener)
        awaitClose {
            newsRef.removeEventListener(listener)
        }
    }

}
