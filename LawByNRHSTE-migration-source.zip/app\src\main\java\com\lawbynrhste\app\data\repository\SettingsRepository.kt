package com.lawbynrhste.app.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.BugReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

data class AppPreferences(
    val darkTheme: Boolean = true,
    val dataSaver: Boolean = true,
    val notifyMessages: Boolean = true,
    val notifyCommunity: Boolean = true,
    val notifyAnnouncements: Boolean = true
)

class SettingsRepository(
    context: Context,
    private val rtdb: FirebaseDatabase = FirebaseManager.database
) {
    private val prefs: SharedPreferences = context.getSharedPreferences("lawby_app_prefs", Context.MODE_PRIVATE)

    private val _preferences = MutableStateFlow(loadPreferences())
    val preferences: StateFlow<AppPreferences> = _preferences.asStateFlow()

    private fun loadPreferences(): AppPreferences {
        return AppPreferences(
            darkTheme = prefs.getBoolean("dark_theme", true),
            dataSaver = prefs.getBoolean("data_saver", true),
            notifyMessages = prefs.getBoolean("notify_messages", true),
            notifyCommunity = prefs.getBoolean("notify_community", true),
            notifyAnnouncements = prefs.getBoolean("notify_announcements", true)
        )
    }

    fun setDataSaver(enabled: Boolean) {
        prefs.edit().putBoolean("data_saver", enabled).apply()
        _preferences.value = _preferences.value.copy(dataSaver = enabled)
    }

    fun setNotificationPreference(type: String, enabled: Boolean) {
        val editor = prefs.edit()
        when (type) {
            "messages" -> {
                editor.putBoolean("notify_messages", enabled)
                _preferences.value = _preferences.value.copy(notifyMessages = enabled)
            }
            "community" -> {
                editor.putBoolean("notify_community", enabled)
                _preferences.value = _preferences.value.copy(notifyCommunity = enabled)
            }
            "announcements" -> {
                editor.putBoolean("notify_announcements", enabled)
                _preferences.value = _preferences.value.copy(notifyAnnouncements = enabled)
            }
        }
        editor.apply()
    }

    /**
     * Files a structured bug report through the authorized RTDB reports path.
     * Sanitizes input to avoid leaking stack traces, credentials, or private message bodies.
     */
    suspend fun submitBugReport(
        currentUid: String,
        category: String,
        description: String
    ): Result<String> {
        val cleanDesc = description.trim()
        if (cleanDesc.isBlank()) return Result.Error(IllegalArgumentException("Description cannot be empty"))

        val safeReason = "[$category] $cleanDesc"
        val reportRef = rtdb.getReference("reports").push()
        val reportData = mapOf(
            "reporterUid" to currentUid,
            "reportedUid" to "platform_issue",
            "reason" to safeReason,
            "timestamp" to ServerValue.TIMESTAMP
        )

        return try {
            reportRef.setValue(reportData).await()
            Result.Success(reportRef.key ?: "")
        } catch (e: Exception) {
            Result.Error(e, "Failed to submit bug report: ${e.message}")
        }
    }

    /**
     * Requests reversible account deactivation.
     * Accurately communicates that permanent purge depends on backend service deployment.
     */
    suspend fun requestAccountDeactivation(currentUid: String, reason: String): Result<Unit> {
        return try {
            val payload = mapOf(
                "status" to "deactivated",
                "deactivationRequestedAt" to System.currentTimeMillis(),
                "deactivationReason" to reason.take(200)
            )
            rtdb.getReference("users/$currentUid/deactivation").setValue(payload).await()
            Result.Success(Unit)
        } catch (e: Exception) {
            Result.Error(e, "Failed to register deactivation request")
        }
    }
}

