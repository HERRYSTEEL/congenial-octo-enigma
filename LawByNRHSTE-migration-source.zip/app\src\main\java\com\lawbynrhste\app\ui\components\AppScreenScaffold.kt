package com.lawbynrhste.app.ui.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.Obsidian

@Composable
fun AppScreenScaffold(
    title: String,
    currentRoute: String,
    onNavigate: (String) -> Unit,
    onBack: (() -> Unit)? = null,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0,
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            LawTopAppBar(
                title = title,
                onNotificationsClick = { onNavigate(Screen.Notifications.route) },
                unreadNotificationsCount = unreadNotificationsCount,
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = GoldAccent)
                        }
                    }
                }
            )
        },
        bottomBar = {
            LawBottomNavigationBar(
                currentRoute = currentRoute,
                onNavigate = onNavigate,
                unreadMessagesCount = unreadMessagesCount
            )
        },
        containerColor = Obsidian,
        content = content
    )
}
