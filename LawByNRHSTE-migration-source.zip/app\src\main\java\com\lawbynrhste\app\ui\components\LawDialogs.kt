package com.lawbynrhste.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.Obsidian
import com.lawbynrhste.app.ui.theme.StateDanger
import com.lawbynrhste.app.ui.theme.StateFrozen
import com.lawbynrhste.app.ui.theme.SurfaceBorder
import com.lawbynrhste.app.ui.theme.SurfaceDark
import com.lawbynrhste.app.ui.theme.TextMuted
import com.lawbynrhste.app.ui.theme.TextPrimary
import com.lawbynrhste.app.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TermsConsentDialog(
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = GoldAccent,
                    modifier = Modifier.size(44.dp)
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "POPIA & PLATFORM TERMS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = GoldAccent
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Welcome to LawByNRHSTE. In compliance with the South African Protection of Personal Information Act (POPIA) and our Community Code of Ethics:\n\n" +
                            "• We collect your account details, research submissions, and platform activity solely to provide peer legal learning, direct messaging, and community features.\n" +
                            "• You agree to maintain professional standard of care, cite sources, respect peer privacy, and provide no unauthorized legal advice.\n" +
                            "• Your consent records are stored securely under your account.\n\n" +
                            "Do you agree to our Terms of Use and Cookie Policy?",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, lineHeight = 20.sp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                GoldButton(
                    text = "I AGREE & ACCEPT",
                    onClick = onAccept
                )
                Spacer(modifier = Modifier.height(10.dp))
                GoldOutlinedButton(
                    text = "DECLINE",
                    onClick = onDecline,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountFrozenDialog(
    onRetry: () -> Unit,
    onSignOut: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Obsidian,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, StateFrozen),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.AcUnit,
                    contentDescription = "Frozen",
                    tint = StateFrozen,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "ACCOUNT FROZEN",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = StateFrozen,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Your access has been suspended by administration due to a policy violation or security audit.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                GoldOutlinedButton(
                    text = "RETRY AUTHENTICATION",
                    onClick = onRetry,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                GoldButton(
                    text = "SIGN OUT",
                    onClick = onSignOut
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAlertDialog(
    message: String,
    onDismiss: () -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = onDismiss
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldAccent),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Notification",
                    tint = GoldAccent,
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "SYSTEM NOTIFICATION",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(22.dp))
                GoldButton(
                    text = "ACKNOWLEDGE",
                    onClick = onDismiss
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeactivationRequestDialog(
    onDismiss: () -> Unit,
    onConfirm: (reason: String) -> Unit
) {
    var reason by remember { mutableStateOf("") }

    BasicAlertDialog(
        onDismissRequest = onDismiss
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = SurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, StateDanger.copy(alpha = 0.5f)),
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = "DEACTIVATE ACCOUNT",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = StateDanger
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Notice: Submitting this request places your profile in temporary deactivation. You can restore your profile anytime by signing back in.\n\n" +
                            "Permanent deletion of historical data depends on deployed backend cleanup services and administrator verification.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, lineHeight = 18.sp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                LawTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = "Reason for deactivation (optional)",
                    placeholder = "Brief explanation...",
                    singleLine = false,
                    maxLines = 3
                )
                Spacer(modifier = Modifier.height(20.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    GoldOutlinedButton(
                        text = "CANCEL",
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    GoldButton(
                        text = "DEACTIVATE",
                        onClick = { onConfirm(reason) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

