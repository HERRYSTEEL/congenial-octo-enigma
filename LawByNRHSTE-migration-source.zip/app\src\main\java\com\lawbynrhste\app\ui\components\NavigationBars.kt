package com.lawbynrhste.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lawbynrhste.app.R
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.Obsidian
import com.lawbynrhste.app.ui.theme.StateDanger
import com.lawbynrhste.app.ui.theme.SurfaceBorder
import com.lawbynrhste.app.ui.theme.SurfaceDark
import com.lawbynrhste.app.ui.theme.TextMuted
import com.lawbynrhste.app.ui.theme.TextPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LawTopAppBar(
    title: String,
    onNotificationsClick: (() -> Unit)? = null,
    unreadNotificationsCount: Int = 0,
    navigationIcon: @Composable (() -> Unit)? = null,
    actions: @Composable (() -> Unit)? = null
) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_scales_of_justice),
                    contentDescription = "Scales of Justice Logo",
                    tint = GoldAccent,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
            }
        },
        navigationIcon = { navigationIcon?.invoke() },
        actions = {
            if (onNotificationsClick != null) {
                IconButton(onClick = onNotificationsClick) {
                    BadgedBox(
                        badge = {
                            if (unreadNotificationsCount > 0) {
                                Badge(
                                    containerColor = StateDanger,
                                    contentColor = Color.White
                                ) {
                                    Text(
                                        text = if (unreadNotificationsCount > 99) "99+" else "$unreadNotificationsCount",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications ($unreadNotificationsCount unread)",
                            tint = GoldAccent
                        )
                    }
                }
            }
            actions?.invoke()
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Obsidian,
            titleContentColor = TextPrimary
        ),
        modifier = Modifier.border(
            width = (0.5).dp,
            color = SurfaceBorder
        )
    )
}

data class BottomNavItem(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

@Composable
fun LawBottomNavigationBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    unreadMessagesCount: Int = 0
) {
    val items = listOf(
        BottomNavItem(
            route = Screen.Dashboard.route,
            label = "Home",
            icon = Icons.Default.Dashboard
        ),
        BottomNavItem(
            route = Screen.Lobby.route,
            label = "Lobby",
            icon = Icons.Default.Forum
        ),
        BottomNavItem(
            route = Screen.Articles.route,
            label = "Articles",
            icon = Icons.Default.Article
        ),
        BottomNavItem(
            route = Screen.Messages.route,
            label = "Messages",
            icon = Icons.Default.ChatBubble,
            badgeCount = unreadMessagesCount
        ),
        BottomNavItem(
            route = Screen.Profile.route,
            label = "Profile",
            icon = Icons.Default.Person
        )
    )

    NavigationBar(
        containerColor = SurfaceDark,
        contentColor = TextMuted,
        tonalElevation = 0.dp,
        modifier = Modifier.border(width = (0.5).dp, color = SurfaceBorder)
    ) {
        items.forEach { item ->
            val isSelected = currentRoute == item.route
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(item.route) },
                icon = {
                    if (item.badgeCount > 0) {
                        BadgedBox(
                            badge = {
                                Badge(
                                    containerColor = GoldAccent,
                                    contentColor = Obsidian
                                ) {
                                    Text(
                                        text = if (item.badgeCount > 99) "99+" else "${item.badgeCount}",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label
                            )
                        }
                    } else {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label
                        )
                    }
                },
                label = {
                    Text(
                        text = item.label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Obsidian,
                    selectedTextColor = GoldAccent,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted,
                    indicatorColor = GoldAccent
                )
            )
        }
    }
}

