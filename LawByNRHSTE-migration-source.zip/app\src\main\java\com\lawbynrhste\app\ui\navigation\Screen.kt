package com.lawbynrhste.app.ui.navigation

sealed class Screen(val route: String) {
    data object SignIn : Screen("sign_in")
    data object SignUp : Screen("sign_up")
    data object ForgotPassword : Screen("forgot_password")

    data object Dashboard : Screen("dashboard")
    data object Profile : Screen("profile")
    data object Lobby : Screen("lobby")
    data object Discussions : Screen("discussions")
    data object CreatePost : Screen("create_post")

    data object Articles : Screen("articles")
    data object ArticleDetail : Screen("article_detail/{articleId}") {
        fun createRoute(articleId: String) = "article_detail/$articleId"
    }
    data object ArticleEditor : Screen("article_editor?articleId={articleId}") {
        fun createRoute(articleId: String? = null) = if (articleId != null) "article_editor?articleId=$articleId" else "article_editor"
    }

    data object Messages : Screen("messages")
    data object ChatRoom : Screen("chat_room/{recipientUid}/{recipientName}") {
        fun createRoute(recipientUid: String, recipientName: String): String {
            val encodedName = java.net.URLEncoder.encode(recipientName, "UTF-8")
            return "chat_room/$recipientUid/$encodedName"
        }
    }

    data object Resources : Screen("resources")
    data object Directory : Screen("directory")
    data object MemberProfile : Screen("member_profile/{uid}") {
        fun createRoute(uid: String) = "member_profile/$uid"
    }

    data object Notifications : Screen("notifications")
    data object Settings : Screen("settings")
    data object AdminTerminal : Screen("admin_terminal")
}
