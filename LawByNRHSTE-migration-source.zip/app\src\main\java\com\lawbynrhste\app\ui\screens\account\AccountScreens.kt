package com.lawbynrhste.app.ui.screens.account

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfRenderer
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.compose.foundation.Image
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.lawbynrhste.app.core.IdGenerator
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.firebase.FirebaseManager
import com.lawbynrhste.app.data.model.AuthSessionState
import com.lawbynrhste.app.data.model.ConversationOverview
import com.lawbynrhste.app.data.model.PrivateMessage
import com.lawbynrhste.app.data.repository.AdminRepository
import com.lawbynrhste.app.data.repository.AuthRepository
import com.lawbynrhste.app.data.repository.MessagingRepository
import com.lawbynrhste.app.data.repository.SettingsRepository
import com.lawbynrhste.app.ui.components.AppScreenScaffold
import com.lawbynrhste.app.ui.components.ErrorBanner
import com.lawbynrhste.app.ui.components.GoldButton
import com.lawbynrhste.app.ui.components.GoldOutlinedButton
import com.lawbynrhste.app.ui.components.LawEmptyState
import com.lawbynrhste.app.ui.components.LawGlassCard
import com.lawbynrhste.app.ui.components.LawTextField
import com.lawbynrhste.app.ui.components.UserAvatar
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.theme.BubbleMe
import com.lawbynrhste.app.ui.theme.BubbleMeText
import com.lawbynrhste.app.ui.theme.BubbleThem
import com.lawbynrhste.app.ui.theme.BubbleThemText
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.TextMuted
import com.lawbynrhste.app.ui.theme.TextPrimary
import coil.compose.AsyncImage
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.DateFormat
import java.io.File
import java.util.Date
import java.util.UUID

@Composable
fun MessagesScreen(
    repository: MessagingRepository,
    currentUid: String,
    onNavigate: (String) -> Unit,
    onOpenChat: (String, String) -> Unit,
    unreadNotificationsCount: Int = 0
) {
    var inboxError by remember(repository, currentUid) { mutableStateOf<String?>(null) }
    val inboxFlow = remember(repository, currentUid) {
        repository.observeInboxOverviews(currentUid).catch { failure ->
            inboxError = failure.localizedMessage ?: "Unable to load your inbox."
            emit(emptyList())
        }
    }
    val conversations by inboxFlow.collectAsState(initial = emptyList())
    AppScreenScaffold(
        title = "Messages",
        currentRoute = Screen.Messages.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = unreadNotificationsCount
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (inboxError != null) item { ErrorBanner(inboxError!!) }
            if (conversations.isEmpty()) {
                item {
                    LawEmptyState(
                        icon = { androidx.compose.material3.Icon(Icons.Default.ChatBubble, null, tint = GoldAccent) },
                        title = "No conversations yet",
                        description = inboxError ?: "Start a private conversation from the member directory."
                    )
                }
            }
            items(conversations, key = { it.otherUid }) { conversation ->
                ConversationCard(
                    conversation = conversation,
                    onClick = { onOpenChat(conversation.otherUid, conversation.otherUser?.name ?: "Member") }
                )
            }
        }
    }
}

@Composable
private fun ConversationCard(conversation: ConversationOverview, onClick: () -> Unit) {
    LawGlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            UserAvatar(
                name = conversation.otherUser?.name ?: conversation.otherUid.take(6),
                photoUrl = conversation.otherUser?.photo,
                size = 48.dp,
                verification = conversation.otherUser?.verification
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    conversation.otherUser?.name ?: "User ${conversation.otherUid.take(6)}",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                conversation.otherUser?.username?.takeIf { it.isNotBlank() }?.let {
                    Text("@$it", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                }
                Text(
                    if (conversation.otherUser?.status == "online") "Online" else "Offline",
                    color = if (conversation.otherUser?.status == "online") GoldAccent else TextMuted,
                    style = MaterialTheme.typography.labelSmall
                )
                Text(conversation.preview.ifBlank { "Open conversation" }, color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            if (conversation.unread) Text("NEW", color = GoldAccent, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun ChatRoomScreen(
    repository: MessagingRepository,
    currentUid: String,
    recipientUid: String,
    recipientName: String,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    unreadNotificationsCount: Int = 0
) {
    val roomPath = remember(currentUid, recipientUid) { IdGenerator.canonicalRoomId(currentUid, recipientUid) }
    val context = LocalContext.current
    var messagesError by remember(repository, roomPath) { mutableStateOf<String?>(null) }
    val messagesFlow = remember(repository, roomPath, currentUid) {
        repository.observeMessages(roomPath, currentUid).catch { failure ->
            messagesError = failure.localizedMessage ?: "Unable to load this conversation."
            emit(emptyList())
        }
    }
    val messages by messagesFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var sending by remember { mutableStateOf(false) }
    var selectedPdf by remember { mutableStateOf<PrivateMessage?>(null) }
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            sending = true
            error = null
            scope.launch {
                try {
                    val resolver = context.contentResolver
                    val mimeType = resolver.getType(uri) ?: "application/octet-stream"
                    var fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "Attachment"
                    resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                        ?.use { cursor ->
                            if (cursor.moveToFirst()) {
                                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                if (nameIndex >= 0) fileName = cursor.getString(nameIndex) ?: fileName
                                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex) && cursor.getLong(sizeIndex) > 25L * 1024 * 1024) {
                                    throw IllegalArgumentException("Attachments must be 25 MB or smaller.")
                                }
                            }
                        }
                    val messageType = when {
                        mimeType.startsWith("image/") -> "image"
                        mimeType.startsWith("audio/") -> "voice"
                        mimeType.startsWith("video/") -> "video"
                        else -> "file"
                    }
                    val storageRef = FirebaseManager.storage.reference.child(
                        "private_messages/$roomPath/$currentUid/${UUID.randomUUID()}"
                    )
                    storageRef.putFile(uri).await()
                    val downloadUrl = storageRef.downloadUrl.await().toString()
                    when (val result = repository.sendMessage(
                        repository.prepareDraft(
                            currentUid = currentUid,
                            recipientUid = recipientUid,
                            type = messageType,
                            fileUrl = downloadUrl,
                            fileName = fileName,
                            mimeType = mimeType
                        )
                    )) {
                        is Result.Error -> error = result.message
                        else -> Unit
                    }
                } catch (failure: Exception) {
                    error = failure.localizedMessage ?: "Could not upload this attachment."
                } finally {
                    sending = false
                }
            }
        }
    }
    LaunchedEffect(currentUid, recipientUid) { repository.markInboxRead(currentUid, recipientUid) }
    AppScreenScaffold(
        title = recipientName,
        currentRoute = Screen.Messages.route,
        onNavigate = onNavigate,
        onBack = onBack,
        unreadNotificationsCount = unreadNotificationsCount
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp, vertical = 10.dp)) {
            if (error != null) ErrorBanner(error!!)
            if (messagesError != null) ErrorBanner(messagesError!!)
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                reverseLayout = false
            ) {
                if (messages.isEmpty()) {
                    item { Text("Say hello to start this conversation.", color = TextMuted) }
                }
                items(messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        currentUid = currentUid,
                        onOpenPdf = { selectedPdf = message }
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    enabled = !sending,
                    onClick = { attachmentPicker.launch("*/*") }
                ) {
                    androidx.compose.material3.Icon(Icons.Default.AttachFile, contentDescription = "Attach a file", tint = GoldAccent)
                }
                LawTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    placeholder = "Message",
                    singleLine = false,
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                )
                OutlinedButton(
                    enabled = text.isNotBlank() && !sending,
                    onClick = {
                        val cleanText = text.trim()
                        if (cleanText.isEmpty()) return@OutlinedButton
                        val draft = repository.prepareDraft(currentUid, recipientUid, text = cleanText)
                        sending = true
                        error = null
                        scope.launch {
                            when (val result = repository.sendMessage(draft)) {
                                is Result.Success -> text = ""
                                is Result.Error -> error = result.message
                                Result.Loading -> Unit
                            }
                            sending = false
                        }
                    }
                ) {
                    androidx.compose.material3.Icon(Icons.Default.Send, contentDescription = "Send message", tint = GoldAccent)
                }
            }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("😀", "😂", "❤️", "👍", "🙏", "⚖️").forEach { emoji ->
                    Text(
                        emoji,
                        modifier = Modifier.clickable { text += emoji }.padding(vertical = 8.dp),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }
    selectedPdf?.let { message ->
        message.fileUrl?.let { url ->
            PdfAttachmentViewer(
                fileName = message.fileName ?: "Document.pdf",
                fileUrl = url,
                onDismiss = { selectedPdf = null }
            )
        }
    }
}

@Composable
private fun MessageBubble(
    message: PrivateMessage,
    currentUid: String,
    onOpenPdf: () -> Unit
) {
    val mine = message.sender == currentUid
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        androidx.compose.material3.Surface(
            color = if (mine) BubbleMe else BubbleThem,
            shape = MaterialTheme.shapes.medium
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                when (message.type) {
                    "image" -> {
                        if (!message.fileUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = message.fileUrl,
                                contentDescription = message.fileName ?: "Shared photo",
                                modifier = Modifier.width(220.dp).height(180.dp),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text("Photo unavailable", color = if (mine) BubbleMeText else BubbleThemText)
                        }
                    }
                    "voice" -> {
                        message.fileUrl?.let { VoiceMessagePlayer(it) }
                            ?: Text("Voice message unavailable", color = if (mine) BubbleMeText else BubbleThemText)
                    }
                    "video" -> {
                        message.fileUrl?.let { VideoMessagePlayer(it) }
                            ?: Text("Video unavailable", color = if (mine) BubbleMeText else BubbleThemText)
                    }
                    "file" -> {
                        val fileLabel = message.fileName
                            ?: "Shared file"
                        GoldOutlinedButton(
                            text = fileLabel,
                            enabled = !message.fileUrl.isNullOrBlank(),
                            onClick = {
                                if (message.mimeType.equals("application/pdf", ignoreCase = true) ||
                                    fileLabel.endsWith(".pdf", ignoreCase = true)
                                ) {
                                    onOpenPdf()
                                } else {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(Uri.parse(message.fileUrl), message.mimeType ?: "*/*")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    try {
                                        context.startActivity(intent)
                                    } catch (_: ActivityNotFoundException) {
                                        android.widget.Toast.makeText(context, "No compatible viewer is installed for this file.", android.widget.Toast.LENGTH_SHORT).show()
                                    } catch (failure: Exception) {
                                        android.widget.Toast.makeText(context, failure.localizedMessage ?: "Could not open this file.", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        )
                    }
                    else -> Text(message.text.orEmpty(), color = if (mine) BubbleMeText else BubbleThemText)
                }
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(message.timestamp)),
                        color = if (mine) BubbleMeText.copy(alpha = 0.7f) else TextMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                    if (mine) {
                        Text(
                            when {
                                message.seen -> "✓✓"
                                message.delivered -> "✓✓"
                                else -> "✓"
                            },
                            color = if (message.seen) GoldAccent else if (mine) BubbleMeText.copy(alpha = 0.75f) else TextMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceMessagePlayer(fileUrl: String) {
    val player = remember(fileUrl) { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember(fileUrl) { mutableStateOf(false) }
    var loading by remember(fileUrl) { mutableStateOf(false) }
    var playbackError by remember(fileUrl) { mutableStateOf<String?>(null) }

    DisposableEffect(fileUrl) {
        onDispose {
            player.value?.release()
            player.value = null
        }
    }

    Column {
        GoldOutlinedButton(
            text = when {
                loading -> "Loading voice message…"
                playing -> "Pause voice message"
                else -> "Play voice message"
            },
            enabled = !loading,
            onClick = {
                playbackError = null
                val activePlayer = player.value
                if (activePlayer != null) {
                    try {
                        if (playing) {
                            activePlayer.pause()
                            playing = false
                        } else {
                            activePlayer.start()
                            playing = true
                        }
                    } catch (failure: IllegalStateException) {
                        playbackError = "This voice message could not be played."
                        activePlayer.release()
                        player.value = null
                        playing = false
                    }
                } else {
                    loading = true
                    try {
                        MediaPlayer().also { mediaPlayer ->
                            player.value = mediaPlayer
                            mediaPlayer.setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build()
                            )
                            mediaPlayer.setOnPreparedListener {
                                loading = false
                                try {
                                    it.start()
                                    playing = true
                                } catch (_: IllegalStateException) {
                                    playbackError = "This voice message could not be played."
                                    it.release()
                                    player.value = null
                                }
                            }
                            mediaPlayer.setOnCompletionListener {
                                playing = false
                                it.release()
                                player.value = null
                            }
                            mediaPlayer.setOnErrorListener { failedPlayer, _, _ ->
                                loading = false
                                playing = false
                                playbackError = "This voice message is unavailable or uses an unsupported format."
                                failedPlayer.release()
                                player.value = null
                                true
                            }
                            mediaPlayer.setDataSource(fileUrl)
                            mediaPlayer.prepareAsync()
                        }
                    } catch (failure: Exception) {
                        player.value?.release()
                        player.value = null
                        loading = false
                        playing = false
                        playbackError = failure.localizedMessage ?: "Could not load this voice message."
                    }
                }
            }
        )
        playbackError?.let {
            Text(it, color = if (playing) BubbleMeText else TextMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun VideoMessagePlayer(fileUrl: String) {
    var playbackError by remember(fileUrl) { mutableStateOf(false) }
    var videoView by remember(fileUrl) { mutableStateOf<VideoView?>(null) }
    DisposableEffect(fileUrl) {
        onDispose {
            videoView?.stopPlayback()
            videoView = null
        }
    }
    if (playbackError) {
        Text("This video could not be played on this device.", color = TextMuted)
    } else {
        androidx.compose.ui.viewinterop.AndroidView(
            factory = { viewContext ->
                VideoView(viewContext).also { video ->
                    videoView = video
                    video.setVideoURI(Uri.parse(fileUrl))
                    video.setMediaController(MediaController(viewContext).apply { setAnchorView(video) })
                    video.setOnErrorListener { _, _, _ ->
                        playbackError = true
                        true
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(220.dp),
            update = { video ->
                if (video.tag != fileUrl) {
                    video.tag = fileUrl
                    video.setVideoURI(Uri.parse(fileUrl))
                }
            }
        )
    }
}

private data class OpenPdfDocument(
    val file: File,
    val descriptor: ParcelFileDescriptor,
    val renderer: PdfRenderer
)

@Composable
private fun PdfAttachmentViewer(fileName: String, fileUrl: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var document by remember(fileUrl) { mutableStateOf<OpenPdfDocument?>(null) }
    var pageIndex by remember(fileUrl) { mutableStateOf(0) }
    var pageBitmap by remember(fileUrl) { mutableStateOf<Bitmap?>(null) }
    var error by remember(fileUrl) { mutableStateOf<String?>(null) }

    LaunchedEffect(fileUrl) {
        try {
            val downloadedFile = withContext(Dispatchers.IO) {
                val cachedFile = File.createTempFile("lawbynrhste-preview-", ".pdf", context.cacheDir)
                try {
                    com.google.firebase.storage.FirebaseStorage.getInstance()
                        .getReferenceFromUrl(fileUrl)
                        .getFile(cachedFile)
                        .await()
                    if (cachedFile.length() > 25L * 1024 * 1024) {
                        throw IllegalArgumentException("This PDF is larger than the 25 MB preview limit.")
                    }
                    cachedFile
                } catch (failure: Exception) {
                    cachedFile.delete()
                    throw failure
                }
            }
            document = withContext(Dispatchers.IO) {
                val descriptor = ParcelFileDescriptor.open(downloadedFile, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    OpenPdfDocument(downloadedFile, descriptor, PdfRenderer(descriptor))
                } catch (failure: Exception) {
                    descriptor.close()
                    downloadedFile.delete()
                    throw failure
                }
            }
        } catch (failure: Exception) {
            error = failure.localizedMessage ?: "Could not load this PDF."
        }
    }

    LaunchedEffect(document, pageIndex) {
        val openDocument = document ?: return@LaunchedEffect
        try {
            pageBitmap = withContext(Dispatchers.IO) {
                val page = openDocument.renderer.openPage(pageIndex)
                try {
                    val scale = minOf(1200f / page.width, 1800f / page.height)
                    val width = (page.width * scale).toInt().coerceAtLeast(1)
                    val height = (page.height * scale).toInt().coerceAtLeast(1)
                    Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
                        Canvas(bitmap).apply { drawColor(android.graphics.Color.WHITE) }
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    }
                } finally {
                    page.close()
                }
            }
        } catch (failure: Exception) {
            error = failure.localizedMessage ?: "Could not render this PDF page."
        }
    }

    DisposableEffect(document) {
        onDispose {
            document?.let {
                it.renderer.close()
                it.descriptor.close()
                it.file.delete()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        androidx.compose.material3.Surface(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(fileName, color = TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1)
                when {
                    error != null -> ErrorBanner(error!!)
                    document == null || pageBitmap == null -> Box(
                        Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) { CircularProgressIndicator(color = GoldAccent) }
                    else -> Image(
                        bitmap = pageBitmap!!.asImageBitmap(),
                        contentDescription = "PDF page ${pageIndex + 1}",
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentScale = ContentScale.Fit
                    )
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        enabled = document != null && pageIndex > 0,
                        onClick = { pageIndex-- }
                    ) { Text("Previous") }
                    document?.let {
                        Text("${pageIndex + 1} / ${it.renderer.pageCount}", color = TextMuted)
                    }
                    TextButton(
                        enabled = document != null && pageIndex < (document?.renderer?.pageCount ?: 1) - 1,
                        onClick = { pageIndex++ }
                    ) { Text("Next") }
                    TextButton(onClick = onDismiss) { Text("Close") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    repository: SettingsRepository,
    authRepository: AuthRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onSignedOut: () -> Unit,
    unreadNotificationsCount: Int = 0
) {
    val preferences by repository.preferences.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var showBugDialog by remember { mutableStateOf(false) }
    var showDeactivateDialog by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("Bug") }
    var report by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    AppScreenScaffold(
        title = "Settings",
        currentRoute = Screen.Profile.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = unreadNotificationsCount
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                LawGlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Preferences", color = GoldAccent, fontWeight = FontWeight.Bold)
                        PreferenceRow("Data saver", "Reduce background data usage", preferences.dataSaver) {
                            repository.setDataSaver(it)
                        }
                        PreferenceRow("Message notifications", "", preferences.notifyMessages) {
                            repository.setNotificationPreference("messages", it)
                        }
                        PreferenceRow("Community notifications", "", preferences.notifyCommunity) {
                            repository.setNotificationPreference("community", it)
                        }
                        PreferenceRow("Platform announcements", "", preferences.notifyAnnouncements) {
                            repository.setNotificationPreference("announcements", it)
                        }
                    }
                }
            }
            if (error != null) item { ErrorBanner(error!!) }
            if (message != null) item { Text(message!!, color = GoldAccent) }
            item {
                LawGlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Legal & privacy", color = GoldAccent, fontWeight = FontWeight.Bold)
                        Text(
                            "Review the platform Terms of Use and Privacy Notice.",
                            color = TextMuted,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(
                                onClick = {
                                    try {
                                        context.startActivity(
                                            Intent(
                                                Intent.ACTION_VIEW,
                                                Uri.parse("https://lawbynrhste.web.app/guidelines.html#terms")
                                            )
                                        )
                                    } catch (_: ActivityNotFoundException) {
                                        error = "No browser is available to open the Terms of Use."
                                    }
                                }
                            ) { Text("Terms of Use", color = GoldAccent) }
                            TextButton(
                                onClick = {
                                    try {
                                        context.startActivity(
                                            Intent(
                                                Intent.ACTION_VIEW,
                                                Uri.parse("https://lawbynrhste.web.app/guidelines.html#privacy")
                                            )
                                        )
                                    } catch (_: ActivityNotFoundException) {
                                        error = "No browser is available to open the Privacy Notice."
                                    }
                                }
                            ) { Text("Privacy Notice", color = GoldAccent) }
                        }
                    }
                }
            }
            if (sessionState.isPlatformAdmin) {
                item {
                    GoldOutlinedButton(
                        "Admin terminal",
                        onClick = { onNavigate(Screen.AdminTerminal.route) }
                    )
                }
            }
            item {
                GoldOutlinedButton("Report a problem", onClick = { showBugDialog = true })
            }
            item {
                GoldOutlinedButton("Request account deactivation", onClick = { showDeactivateDialog = true })
            }
            item {
                GoldButton("Sign out", onClick = {
                    scope.launch {
                        authRepository.signOut()
                        onSignedOut()
                    }
                })
            }
        }
    }
    if (showBugDialog) {
        AlertDialog(
            onDismissRequest = { showBugDialog = false },
            title = { Text("Report a problem") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LawTextField(category, { category = it }, label = "Category", placeholder = "Bug, feedback…")
                    LawTextField(report, { report = it }, label = "Description", singleLine = false, maxLines = 5)
                }
            },
            confirmButton = {
                TextButton(enabled = report.isNotBlank(), onClick = {
                    val uid = sessionState.uid.orEmpty()
                    scope.launch {
                        when (val result = repository.submitBugReport(uid, category, report)) {
                            is Result.Success -> {
                                message = "Report submitted."
                                report = ""
                                showBugDialog = false
                            }
                            is Result.Error -> error = result.message
                            Result.Loading -> Unit
                        }
                    }
                }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { showBugDialog = false }) { Text("Cancel") } }
        )
    }
    if (showDeactivateDialog) {
        AlertDialog(
            onDismissRequest = { showDeactivateDialog = false },
            title = { Text("Request deactivation?") },
            text = {
                Column {
                    Text("This records a request for the platform team; it does not immediately delete your account.")
                    Spacer(Modifier.height(8.dp))
                    LawTextField(reason, { reason = it }, label = "Reason", singleLine = false, maxLines = 4)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val uid = sessionState.uid.orEmpty()
                    scope.launch {
                        when (val result = repository.requestAccountDeactivation(uid, reason)) {
                            is Result.Success -> {
                                message = "Deactivation request recorded."
                                showDeactivateDialog = false
                            }
                            is Result.Error -> error = result.message
                            Result.Loading -> Unit
                        }
                    }
                }) { Text("Request") }
            },
            dismissButton = { TextButton(onClick = { showDeactivateDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PreferenceRow(title: String, subtitle: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotBlank()) Text(subtitle, color = TextMuted, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
fun AdminTerminalScreen(
    repository: AdminRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit
) {
    val maintenance by repository.observeMaintenance().collectAsState(initial = null)
    val reports by repository.observeBugReports(sessionState.email).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var announcement by remember { mutableStateOf("") }
    var maintenanceMessage by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("24") }
    var error by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    AppScreenScaffold(
        title = "Admin Terminal",
        currentRoute = Screen.Dashboard.route,
        onNavigate = onNavigate,
        onBack = onBack
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (error != null) item { ErrorBanner(error!!) }
            if (status != null) item { Text(status!!, color = GoldAccent) }
            item {
                LawGlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Platform announcement", color = GoldAccent, fontWeight = FontWeight.Bold)
                        LawTextField(announcement, { announcement = it }, label = "Message", singleLine = false, maxLines = 4)
                        LawTextField(duration, { duration = it.filter(Char::isDigit) }, label = "Duration (hours)")
                        GoldButton("Publish announcement", enabled = announcement.isNotBlank(), onClick = {
                            val hours = duration.toIntOrNull()?.coerceIn(1, 720) ?: 24
                            scope.launch {
                                when (val result = repository.publishAnnouncement(announcement, hours, sessionState.email)) {
                                    is Result.Success -> {
                                        status = "Announcement published."
                                        announcement = ""
                                    }
                                    is Result.Error -> error = result.message
                                    Result.Loading -> Unit
                                }
                            }
                        })
                    }
                }
            }
            item {
                LawGlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Maintenance mode", color = GoldAccent, fontWeight = FontWeight.Bold)
                        Text(if (maintenance?.active == true) "Currently active" else "Currently inactive", color = TextMuted)
                        LawTextField(maintenanceMessage, { maintenanceMessage = it }, label = "Maintenance message")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            GoldOutlinedButton("Enable", onClick = {
                                scope.launch {
                                    when (val result = repository.toggleMaintenance(true, maintenanceMessage, sessionState.email)) {
                                        is Result.Success -> status = "Maintenance enabled."
                                        is Result.Error -> error = result.message
                                        Result.Loading -> Unit
                                    }
                                }
                            }, modifier = Modifier.weight(1f))
                            GoldOutlinedButton("Disable", onClick = {
                                scope.launch {
                                    when (val result = repository.toggleMaintenance(false, maintenanceMessage, sessionState.email)) {
                                        is Result.Success -> status = "Maintenance disabled."
                                        is Result.Error -> error = result.message
                                        Result.Loading -> Unit
                                    }
                                }
                            }, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            item { Text("USER REPORTS (${reports.size})", color = GoldAccent, fontWeight = FontWeight.Bold) }
            if (reports.isEmpty()) item { Text("No reports to review.", color = TextMuted) }
            items(reports, key = { it.id }) { report ->
                LawGlassCard(Modifier.fillMaxWidth()) {
                    Column {
                        Text(report.reason, color = TextPrimary)
                        Spacer(Modifier.height(4.dp))
                        Text("Reporter: ${report.reporterUid}", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
