package com.lawbynrhste.app.ui.screens.community

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import coil.compose.AsyncImage
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.model.AuthSessionState
import com.lawbynrhste.app.data.model.DirectoryMember
import com.lawbynrhste.app.data.model.Post
import com.lawbynrhste.app.data.model.PostComment
import com.lawbynrhste.app.data.model.PostLike
import com.lawbynrhste.app.data.model.SUPPORTED_REACTIONS
import com.lawbynrhste.app.data.model.UserProfile
import com.lawbynrhste.app.data.repository.DirectoryRepository
import com.lawbynrhste.app.data.repository.LobbyRepository
import com.lawbynrhste.app.ui.components.AppScreenScaffold
import com.lawbynrhste.app.ui.components.ErrorBanner
import com.lawbynrhste.app.ui.components.GoldButton
import com.lawbynrhste.app.ui.components.GoldOutlinedButton
import com.lawbynrhste.app.ui.components.LawEmptyState
import com.lawbynrhste.app.ui.components.LawGlassCard
import com.lawbynrhste.app.ui.components.LawTextField
import com.lawbynrhste.app.ui.components.UserAvatar
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.TextMuted
import com.lawbynrhste.app.ui.theme.TextPrimary
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.catch
import java.text.DateFormat

private fun String?.ifNullOrBlank(fallback: String): String =
    this?.takeIf(String::isNotBlank) ?: fallback

@Composable
fun LobbyScreen(
    repository: LobbyRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onCreatePost: () -> Unit,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0
) {
    var feedError by remember(repository) { mutableStateOf<String?>(null) }
    val postsFlow = remember(repository) {
        repository.observePosts().catch { error ->
            feedError = error.localizedMessage ?: "Unable to load community posts."
            emit(emptyList())
        }
    }
    val posts by postsFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    var selectedPost by remember { mutableStateOf<Post?>(null) }
    AppScreenScaffold(
        title = "Community Lobby",
        currentRoute = Screen.Lobby.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = unreadNotificationsCount,
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Discuss legal study, practice and research with the community.", color = TextMuted)
                Spacer(Modifier.height(12.dp))
                GoldButton("Create a post", onClick = onCreatePost)
            }
            if (error != null) item { ErrorBanner(error!!) }
            if (feedError != null) item { ErrorBanner(feedError!!) }
            if (posts.isEmpty()) {
                item {
                    LawEmptyState(
                        icon = { Icon(Icons.Default.Forum, contentDescription = null, tint = GoldAccent) },
                        title = if (feedError == null) "The lobby is quiet" else "Community posts unavailable",
                        description = if (feedError == null) {
                            "Be the first to start a respectful legal discussion."
                        } else {
                            "Check your connection or try again later."
                        }
                    )
                }
            }
            items(posts, key = { it.id }) { post ->
                PostCard(
                    post = post,
                    currentUid = sessionState.uid.orEmpty(),
                    currentUserName = sessionState.userAccount?.profile?.name ?: "Member",
                    currentUserEmail = sessionState.email,
                    isPlatformAdmin = sessionState.isPlatformAdmin,
                    repository = repository,
                    onComment = { selectedPost = post },
                    onError = { error = it }
                )
            }
        }
    }
    selectedPost?.let { post ->
        PostCommentDialog(
            post = post,
            repository = repository,
            sessionState = sessionState,
            onDismiss = { selectedPost = null },
            onError = { error = it }
        )
    }
}

@Composable
private fun PostCard(
    post: Post,
    currentUid: String,
    currentUserName: String,
    currentUserEmail: String?,
    isPlatformAdmin: Boolean,
    repository: LobbyRepository,
    onComment: () -> Unit,
    onError: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var working by remember(post.id) { mutableStateOf(false) }
    var likes by remember(post.id) { mutableStateOf(emptyList<PostLike>()) }
    var comments by remember(post.id) { mutableStateOf(emptyList<PostComment>()) }
    var engagementError by remember(post.id) { mutableStateOf<String?>(null) }
    var reactionMenuExpanded by remember(post.id) { mutableStateOf(false) }
    var actionsMenuExpanded by remember(post.id) { mutableStateOf(false) }
    var confirmDelete by remember(post.id) { mutableStateOf(false) }
    val userReaction = likes.firstOrNull { it.uid == currentUid }
    val canDelete = post.uid == currentUid || isPlatformAdmin

    LaunchedEffect(post.id) {
        launch {
            repository.observePostLikes(post.id)
                .catch { engagementError = it.message ?: "Post reactions could not be loaded." }
                .collect { likes = it }
        }
        launch {
            repository.observePostComments(post.id)
                .catch { engagementError = it.message ?: "Post comments could not be loaded." }
                .collect { comments = it }
        }
    }

    LawGlassCard(Modifier.fillMaxWidth()) {
        Column {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                UserAvatar(name = post.author, photoUrl = post.avatar, size = 40.dp)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(
                        post.author,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        post.timestamp?.toDate()?.let {
                            DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(it)
                        } ?: "Recently",
                        color = TextMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                if (canDelete) {
                    Box {
                        IconButton(onClick = { actionsMenuExpanded = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Post options", tint = TextMuted)
                        }
                        DropdownMenu(
                            expanded = actionsMenuExpanded,
                            onDismissRequest = { actionsMenuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Delete post") },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                                onClick = {
                                    actionsMenuExpanded = false
                                    confirmDelete = true
                                }
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(post.text, color = TextPrimary, style = MaterialTheme.typography.bodyLarge)
            if (!post.image.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                AsyncImage(
                    model = post.image,
                    contentDescription = "Image attached to post by ${post.author}",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Crop
                )
            }
            if (engagementError != null) {
                Spacer(Modifier.height(8.dp))
                Text(engagementError.orEmpty(), color = TextMuted, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) {
                    OutlinedButton(
                        enabled = !working && currentUid.isNotBlank(),
                        onClick = {
                            val emoji = userReaction?.emoji ?: SUPPORTED_REACTIONS.first()
                            working = true
                            scope.launch {
                                val result = repository.toggleLike(
                                    postId = post.id,
                                    userId = currentUid,
                                    emoji = emoji,
                                    postAuthorUid = post.uid,
                                    currentUserName = currentUserName
                                )
                                working = false
                                if (result is Result.Error) onError(result.message)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Favorite, contentDescription = null)
                        Text(" ${userReaction?.emoji ?: "React"} ${likes.size}")
                    }
                    DropdownMenu(
                        expanded = reactionMenuExpanded,
                        onDismissRequest = { reactionMenuExpanded = false }
                    ) {
                        SUPPORTED_REACTIONS.forEach { emoji ->
                            DropdownMenuItem(
                                text = { Text(emoji) },
                                onClick = {
                                    reactionMenuExpanded = false
                                    if (currentUid.isBlank()) return@DropdownMenuItem
                                    working = true
                                    scope.launch {
                                        val result = repository.toggleLike(
                                            postId = post.id,
                                            userId = currentUid,
                                            emoji = emoji,
                                            postAuthorUid = post.uid,
                                            currentUserName = currentUserName
                                        )
                                        working = false
                                        if (result is Result.Error) onError(result.message)
                                    }
                                }
                            )
                        }
                    }
                }
                OutlinedButton(onClick = onComment, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Forum, contentDescription = null)
                    Text(" Discuss ${comments.size}")
                }
            }
            TextButton(
                enabled = currentUid.isNotBlank() && !working,
                onClick = { reactionMenuExpanded = true }
            ) {
                Text("Choose a reaction", color = GoldAccent)
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this post?") },
            text = { Text("The post will be removed from the Lobby. This cannot be undone.") },
            confirmButton = {
                TextButton(
                    enabled = !working,
                    onClick = {
                        confirmDelete = false
                        working = true
                        scope.launch {
                            val result = repository.deletePost(post, currentUid, currentUserEmail)
                            working = false
                            if (result is Result.Error) onError(result.message)
                        }
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PostCommentDialog(
    post: Post,
    repository: LobbyRepository,
    sessionState: AuthSessionState,
    onDismiss: () -> Unit,
    onError: (String) -> Unit
) {
    var commentsError by remember(post.id) { mutableStateOf<String?>(null) }
    val commentsFlow = remember(post.id) {
        repository.observePostComments(post.id).catch {
            commentsError = it.message ?: "Comments could not be loaded."
            emit(emptyList())
        }
    }
    val comments by commentsFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var text by remember(post.id) { mutableStateOf("") }
    var submitting by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Discussion") },
        text = {
            Column {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (commentsError != null) {
                        item { Text(commentsError.orEmpty(), color = TextMuted) }
                    }
                    items(comments, key = { it.id }) { comment ->
                        Row(verticalAlignment = androidx.compose.ui.Alignment.Top) {
                            UserAvatar(name = comment.author, photoUrl = null, size = 30.dp)
                            Column(Modifier.padding(start = 8.dp)) {
                                Text(comment.author, color = GoldAccent, fontWeight = FontWeight.Bold)
                                Text(comment.text, color = TextPrimary)
                            }
                        }
                    }
                    if (comments.isEmpty()) item { Text("Start the conversation with a comment.", color = TextMuted) }
                }
                Spacer(Modifier.height(10.dp))
                LawTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = "Write a comment",
                    singleLine = false,
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = !submitting && text.isNotBlank() && !sessionState.uid.isNullOrBlank(),
                onClick = {
                    val uid = sessionState.uid ?: return@TextButton
                    submitting = true
                    scope.launch {
                        val result = repository.addComment(
                            postId = post.id,
                            text = text,
                            currentUserUid = uid,
                            authorName = sessionState.userAccount?.profile?.name ?: "Member",
                            postAuthorUid = post.uid
                        )
                        submitting = false
                        if (result is Result.Success) text = "" else if (result is Result.Error) onError(result.message)
                    }
                }
            ) { Text(if (submitting) "Sending…" else "Send") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
fun CreatePostScreen(
    repository: LobbyRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    onPublished: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var isPublishing by remember { mutableStateOf(false) }
    AppScreenScaffold(
        title = "Create a Post",
        currentRoute = Screen.Lobby.route,
        onNavigate = onNavigate,
        onBack = onBack
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Share a question, insight or legal research update with the community.", color = TextMuted)
            if (error != null) ErrorBanner(error!!)
            LawTextField(
                value = text,
                onValueChange = { text = it },
                label = "Your post",
                placeholder = "What would you like to discuss?",
                singleLine = false,
                maxLines = 12,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
            GoldButton(
                text = "Publish post",
                isLoading = isPublishing,
                enabled = text.isNotBlank(),
                onClick = {
                    val uid = sessionState.uid
                    if (uid.isNullOrBlank()) {
                        error = "Your session has expired. Sign in again to post."
                        return@GoldButton
                    }
                    isPublishing = true
                    scope.launch {
                        val result = repository.createPost(
                            text = text,
                            currentUserUid = uid,
                            authorName = sessionState.userAccount?.profile?.name ?: "Member",
                            authorAvatar = sessionState.userAccount?.profile?.photo.orEmpty()
                        )
                        isPublishing = false
                        when (result) {
                            is Result.Success -> onPublished()
                            is Result.Error -> error = result.message
                            Result.Loading -> Unit
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun DirectoryScreen(
    repository: DirectoryRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onMemberSelected: (String) -> Unit,
    onChatSelected: (String, String) -> Unit,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0
) {
    val uid = sessionState.uid.orEmpty()
    var memberLoadError by remember(repository, uid) { mutableStateOf<String?>(null) }
    val membersFlow = remember(repository, uid) {
        repository.observeMembers(uid).catch { failure ->
            memberLoadError = failure.localizedMessage ?: "Unable to load the member directory."
            emit(emptyList())
        }
    }
    val members by membersFlow.collectAsState(initial = emptyList())
    var search by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val shownMembers = members.filter {
        val query = search.trim()
        query.isEmpty() || it.profile.name.contains(query, true) ||
            it.profile.username.contains(query, true) || it.profile.field.contains(query, true)
    }.sortedWith(compareByDescending<DirectoryMember> { it.followerCount }
        .thenBy { it.profile.username.ifBlank { it.profile.name } })
    AppScreenScaffold(
        title = "Member Directory",
        currentRoute = Screen.Profile.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = unreadNotificationsCount,
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { LawTextField(search, { search = it }, placeholder = "Search members") }
            if (memberLoadError != null) item { ErrorBanner(memberLoadError!!) }
            if (error != null) item { ErrorBanner(error!!) }
            if (shownMembers.isEmpty() && memberLoadError == null) {
                item {
                    LawEmptyState(
                        icon = { Icon(Icons.Default.Person, contentDescription = null, tint = GoldAccent) },
                        title = "No members found",
                        description = "Try another name or field of study."
                    )
                }
            }
            items(shownMembers, key = { it.uid }) { member ->
                MemberCard(
                    member = member,
                    currentUid = uid,
                    currentName = sessionState.userAccount?.profile?.let { profile ->
                        if (profile.showOfficialName == false) {
                            profile.username.ifBlank { profile.name }
                        } else {
                            profile.name.ifBlank { profile.username }
                        }
                    }.orEmpty(),
                    repository = repository,
                    onOpen = { onMemberSelected(member.uid) },
                    onMessage = { onChatSelected(member.uid, member.profile.name) },
                    onError = { error = it }
                )
            }
        }
    }
}

@Composable
private fun MemberCard(
    member: DirectoryMember,
    currentUid: String,
    currentName: String,
    repository: DirectoryRepository,
    onOpen: () -> Unit,
    onMessage: () -> Unit,
    onError: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var sending by remember(member.uid) { mutableStateOf(false) }
    LawGlassCard(Modifier.fillMaxWidth()) {
        Column {
            Row(Modifier.fillMaxWidth()) {
                UserAvatar(member.profile.name, member.profile.photo, size = 44.dp, verification = member.profile.verification)
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text(member.profile.name, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text("@${member.profile.username}", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                    if (member.profile.field.isNotBlank()) Text(member.profile.field, color = GoldAccent, style = MaterialTheme.typography.labelSmall)
                }
                TextButton(onClick = onOpen) { Text("View") }
            }
            if (member.profile.bio.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(member.profile.bio, color = TextMuted, style = MaterialTheme.typography.bodySmall)
            }
            Text("${member.followerCount} followers", color = GoldAccent, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GoldOutlinedButton("Message", onClick = onMessage, modifier = Modifier.weight(1f))
                OutlinedButton(
                    enabled = !sending && currentUid.isNotBlank(),
                    onClick = {
                        sending = true
                        scope.launch {
                            val result = repository.toggleFollow(
                                currentUid = currentUid,
                                targetUid = member.uid,
                                senderName = currentName,
                                isFollowing = member.isFollowing
                            )
                            sending = false
                            if (result is Result.Error) onError(result.message)
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        when {
                            sending -> "Updating…"
                            member.isFollowing -> "Following"
                            else -> "Follow"
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(
    uid: String,
    repository: DirectoryRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0
) {
    val isSelf = uid == sessionState.uid
    var profile by remember(uid) { mutableStateOf(if (isSelf) sessionState.userAccount?.profile else null) }
    var username by remember(uid) { mutableStateOf(profile?.username.orEmpty()) }
    var officialName by remember(uid) { mutableStateOf(profile?.name.orEmpty()) }
    var showOfficialName by remember(uid) { mutableStateOf(profile?.showOfficialName ?: false) }
    var bio by remember(uid) { mutableStateOf(profile?.bio.orEmpty()) }
    var occupation by remember(uid) { mutableStateOf(profile?.occupation.orEmpty()) }
    var highSchool by remember(uid) { mutableStateOf(profile?.highSchool.orEmpty()) }
    var college by remember(uid) { mutableStateOf(profile?.college.orEmpty()) }
    var university by remember(uid) { mutableStateOf(profile?.university.ifNullOrBlank(profile?.education.orEmpty())) }
    var fieldOfStudy by remember(uid) { mutableStateOf(profile?.fieldOfStudy.ifNullOrBlank(profile?.field.orEmpty())) }
    var interests by remember(uid) { mutableStateOf(profile?.interests.orEmpty()) }
    var socialLinks by remember(uid) { mutableStateOf(profile?.socialLinks.orEmpty()) }
    var loading by remember(uid) { mutableStateOf(!isSelf) }
    var editing by remember(uid) { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(uid, sessionState.userAccount?.profile) {
        if (isSelf) {
            profile = sessionState.userAccount?.profile
            username = profile?.username.orEmpty()
            officialName = profile?.name.orEmpty()
            showOfficialName = profile?.showOfficialName ?: false
            bio = profile?.bio.orEmpty()
            occupation = profile?.occupation.orEmpty()
            highSchool = profile?.highSchool.orEmpty()
            college = profile?.college.orEmpty()
            university = profile?.university.ifNullOrBlank(profile?.education.orEmpty())
            fieldOfStudy = profile?.fieldOfStudy.ifNullOrBlank(profile?.field.orEmpty())
            interests = profile?.interests.orEmpty()
            socialLinks = profile?.socialLinks.orEmpty()
            loading = false
            when (val result = repository.getMyOfficialName(uid)) {
                is Result.Success -> if (result.data.isNotBlank()) officialName = result.data
                is Result.Error -> error = result.message
                Result.Loading -> Unit
            }
        } else {
            when (val result = repository.getMemberProfile(uid)) {
                is Result.Success -> profile = result.data
                is Result.Error -> error = result.message
                Result.Loading -> Unit
            }
            loading = false
        }
    }
    AppScreenScaffold(
        title = if (isSelf) "My Profile" else "Member Profile",
        currentRoute = Screen.Profile.route,
        onNavigate = onNavigate,
        onBack = if (isSelf) null else onBack,
        unreadNotificationsCount = unreadNotificationsCount,
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (error != null) item { ErrorBanner(error!!) }
            if (saved) item { Text("Profile updated.", color = GoldAccent) }
            if (loading) item { Text("Loading profile…", color = TextMuted) }
            profile?.let { user ->
                item {
                    LawGlassCard(Modifier.fillMaxWidth()) {
                        Column {
                            UserAvatar(user.name, user.photo, size = 76.dp, verification = user.verification)
                            Spacer(Modifier.height(12.dp))
                            if (isSelf && editing) {
                                LawTextField(username, { username = it }, label = "Username")
                                LawTextField(officialName, { officialName = it }, label = "Official names")
                                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                    Text("Show my official name publicly", color = TextPrimary, modifier = Modifier.weight(1f))
                                    Switch(
                                        checked = showOfficialName,
                                        onCheckedChange = { showOfficialName = it }
                                    )
                                }
                                LawTextField(bio, { bio = it }, label = "Bio", singleLine = false, maxLines = 4)
                                LawTextField(occupation, { occupation = it }, label = "Occupation")
                                LawTextField(highSchool, { highSchool = it }, label = "High school")
                                LawTextField(college, { college = it }, label = "College")
                                LawTextField(university, { university = it }, label = "University")
                                LawTextField(fieldOfStudy, { fieldOfStudy = it }, label = "Field of study")
                                LawTextField(interests, { interests = it }, label = "Hobbies and interests")
                                listOf("instagram", "facebook", "tiktok", "whatsapp", "linkedin", "x", "reddit")
                                    .forEach { platform ->
                                        LawTextField(
                                            value = socialLinks[platform].orEmpty(),
                                            onValueChange = { value ->
                                                socialLinks = socialLinks.toMutableMap().apply {
                                                    if (value.isBlank()) remove(platform) else put(platform, value)
                                                }
                                            },
                                            label = "${platform.replaceFirstChar(Char::uppercase)} URL"
                                        )
                                    }
                            } else {
                                Text(user.name, color = TextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                if (user.username.isNotBlank()) Text("@${user.username}", color = TextMuted)
                                if (user.occupation.isNotBlank()) Text(user.occupation, color = GoldAccent)
                                if (user.bio.isNotBlank()) {
                                    Spacer(Modifier.height(10.dp))
                                    Text(user.bio, color = TextPrimary)
                                }
                                listOf(
                                    "High school" to user.highSchool,
                                    "College" to user.college,
                                    "University" to user.university.ifBlank { user.education },
                                    "Field of study" to user.fieldOfStudy.ifBlank { user.field },
                                    "Interests" to user.interests
                                ).filter { it.second.isNotBlank() }.forEach { (label, value) ->
                                    Text("$label: $value", color = TextMuted)
                                }
                                Text("${user.friendCount} followers", color = GoldAccent, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
                if (isSelf) item {
                    if (!editing) {
                        GoldButton("Edit profile", onClick = { editing = true })
                        Spacer(Modifier.height(8.dp))
                        GoldOutlinedButton(
                            "App settings",
                            onClick = { onNavigate(Screen.Settings.route) }
                        )
                    } else {
                        GoldButton("Save profile", onClick = {
                            val currentUid = sessionState.uid
                            if (currentUid.isNullOrBlank()) {
                                error = "Your session has expired."
                                return@GoldButton
                            }
                            scope.launch {
                                if (username.isBlank()) {
                                    error = "Choose a username before saving."
                                    return@launch
                                }
                                when (val result = repository.updateMyProfile(
                                    currentUid = currentUid,
                                    name = if (showOfficialName) officialName else username,
                                    bio = bio,
                                    education = university.ifBlank { college.ifBlank { highSchool } },
                                    field = fieldOfStudy,
                                    photoUrl = null,
                                    username = username,
                                    officialName = officialName,
                                    showOfficialName = showOfficialName,
                                    occupation = occupation,
                                    highSchool = highSchool,
                                    college = college,
                                    university = university,
                                    fieldOfStudy = fieldOfStudy,
                                    interests = interests,
                                    socialLinks = socialLinks
                                )) {
                                    is Result.Success -> {
                                        saved = true
                                        editing = false
                                    }
                                    is Result.Error -> error = result.message
                                    Result.Loading -> Unit
                                }
                            }

                        })
                    }
                }
            }
        }
    }
}
