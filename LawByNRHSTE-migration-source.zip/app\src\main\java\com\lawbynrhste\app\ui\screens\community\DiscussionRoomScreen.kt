package com.lawbynrhste.app.ui.screens.community

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.model.AuthSessionState
import com.lawbynrhste.app.data.model.ForumDiscussion
import com.lawbynrhste.app.data.repository.ForumRepository
import com.lawbynrhste.app.ui.components.AppScreenScaffold
import com.lawbynrhste.app.ui.components.ErrorBanner
import com.lawbynrhste.app.ui.components.GoldButton
import com.lawbynrhste.app.ui.components.LawEmptyState
import com.lawbynrhste.app.ui.components.LawGlassCard
import com.lawbynrhste.app.ui.components.LawTextField
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.TextMuted
import com.lawbynrhste.app.ui.theme.TextPrimary
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun DiscussionRoomScreen(
    repository: ForumRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var isPosting by remember { mutableStateOf(false) }
    var actionError by remember { mutableStateOf<String?>(null) }
    var feedError by remember(repository) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val discussionsFlow = remember(repository) {
        repository.observeDiscussions().catch { error ->
            feedError = error.localizedMessage ?: "Unable to load discussions."
            emit(emptyList())
        }
    }
    val discussions by discussionsFlow.collectAsState(initial = emptyList())
    val authorName = sessionState.userAccount?.profile?.let { profile ->
        if (profile.showOfficialName == false) {
            profile.username.ifBlank { profile.name }
        } else {
            profile.name.ifBlank { profile.username }
        }
    }?.ifBlank { "Member" } ?: "Member"

    AppScreenScaffold(
        title = "Discussion Room",
        currentRoute = Screen.Discussions.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = unreadNotificationsCount,
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (actionError != null) item { ErrorBanner(actionError!!) }
            if (feedError != null) item { ErrorBanner(feedError!!) }
            item {
                LawGlassCard(Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            "Ask short legal questions, debate current affairs, and share early ideas. Do not post private or confidential information.",
                            color = TextMuted,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        LawTextField(
                            value = title,
                            onValueChange = { title = it.take(120) },
                            label = "Topic title",
                            placeholder = "What would you like to discuss?"
                        )
                        LawTextField(
                            value = body,
                            onValueChange = { body = it.take(1000) },
                            label = "Message",
                            placeholder = "Share a question or idea (up to 1,000 characters).",
                            singleLine = false,
                            maxLines = 6,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences
                            )
                        )
                        Text("${body.length} / 1,000 characters", color = TextMuted, style = MaterialTheme.typography.labelSmall)
                        GoldButton(
                            text = "Post discussion",
                            isLoading = isPosting,
                            enabled = title.isNotBlank() && body.isNotBlank() &&
                                sessionState.uid != null && !isPosting,
                            onClick = {
                                val uid = sessionState.uid
                                if (uid.isNullOrBlank()) {
                                    actionError = "Sign in again before posting."
                                    return@GoldButton
                                }
                                isPosting = true
                                actionError = null
                                scope.launch {
                                    when (val result = repository.createDiscussion(title, body, uid, authorName)) {
                                        is Result.Success -> {
                                            title = ""
                                            body = ""
                                        }
                                        is Result.Error -> actionError = result.message
                                        Result.Loading -> Unit
                                    }
                                    isPosting = false
                                }
                            }
                        )
                    }
                }
            }
            if (discussions.isEmpty()) {
                item {
                    LawEmptyState(
                        icon = { Icon(Icons.Default.Forum, contentDescription = null, tint = GoldAccent) },
                        title = if (feedError == null) "No discussions yet" else "Discussions unavailable",
                        description = if (feedError == null) {
                            "Start a constructive legal discussion with the community."
                        } else {
                            "Check your connection or permissions, then try again."
                        }
                    )
                }
            }
            items(discussions, key = { it.id }) { discussion ->
                DiscussionCard(
                    discussion = discussion,
                    repository = repository,
                    currentUid = sessionState.uid.orEmpty(),
                    authorName = authorName,
                    onError = { actionError = it }
                )
            }
        }
    }
}

@Composable
private fun DiscussionCard(
    discussion: ForumDiscussion,
    repository: ForumRepository,
    currentUid: String,
    authorName: String,
    onError: (String) -> Unit
) {
    var reply by remember(discussion.id) { mutableStateOf("") }
    var isReplying by remember(discussion.id) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LawGlassCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "${discussion.authorName} · ${formatDiscussionDate(discussion.createdAt)}",
                color = TextMuted,
                style = MaterialTheme.typography.labelSmall
            )
            Text(discussion.title, color = GoldAccent, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(discussion.body, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)

            discussion.replies.forEach { discussionReply ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 10.dp)
                ) {
                    Text(
                        "${discussionReply.authorName} · ${formatDiscussionDate(discussionReply.timestamp)}",
                        color = GoldAccent,
                        style = MaterialTheme.typography.labelSmall
                    )
                    Text(discussionReply.body, color = TextPrimary, style = MaterialTheme.typography.bodySmall)
                }
            }

            if (currentUid.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                LawTextField(
                    value = reply,
                    onValueChange = { reply = it.take(500) },
                    label = "Reply",
                    placeholder = "Write a reply (up to 500 characters).",
                    singleLine = false,
                    maxLines = 4,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences
                    )
                )
                GoldButton(
                    text = "Reply",
                    isLoading = isReplying,
                    enabled = reply.isNotBlank() && !isReplying,
                    onClick = {
                        isReplying = true
                        scope.launch {
                            when (val result = repository.replyToDiscussion(
                                discussion = discussion,
                                body = reply,
                                currentUid = currentUid,
                                authorName = authorName
                            )) {
                                is Result.Success -> reply = ""
                                is Result.Error -> {
                                    if (result.message.startsWith("Your reply was posted")) reply = ""
                                    onError(result.message)
                                }
                                Result.Loading -> Unit
                            }
                            isReplying = false
                        }
                    }
                )
            }
        }
    }
}

private fun formatDiscussionDate(timestamp: Long): String =
    if (timestamp > 0) DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(timestamp))
    else "Just now"
