package com.lawbynrhste.app.ui.screens.content

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lawbynrhste.app.core.Result
import com.lawbynrhste.app.data.model.Article
import com.lawbynrhste.app.data.model.AuthSessionState
import com.lawbynrhste.app.data.model.NotificationItem
import com.lawbynrhste.app.data.repository.ArticlesRepository
import com.lawbynrhste.app.data.repository.NotificationsRepository
import com.lawbynrhste.app.data.repository.ResourcesRepository
import com.lawbynrhste.app.ui.components.AppScreenScaffold
import com.lawbynrhste.app.ui.components.ErrorBanner
import com.lawbynrhste.app.ui.components.GoldButton
import com.lawbynrhste.app.ui.components.GoldOutlinedButton
import com.lawbynrhste.app.ui.components.LawEmptyState
import com.lawbynrhste.app.ui.components.LawGlassCard
import com.lawbynrhste.app.ui.components.LawTextField
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.Obsidian
import com.lawbynrhste.app.ui.theme.SurfaceGlassElevated
import com.lawbynrhste.app.ui.theme.TextMuted
import com.lawbynrhste.app.ui.theme.TextPrimary
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.catch
import java.text.DateFormat
import java.util.Date
import java.util.UUID

@Composable
fun ArticlesScreen(
    repository: ArticlesRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onArticleSelected: (String) -> Unit,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0
) {
    var feedError by remember(repository) { mutableStateOf<String?>(null) }
    val articlesFlow = remember(repository) {
        repository.observeArticles().catch { error ->
            feedError = error.localizedMessage ?: "Unable to load articles from the server."
            emit(emptyList())
        }
    }
    val articles by articlesFlow.collectAsState(initial = emptyList())
    AppScreenScaffold(
        title = "Legal Articles",
        currentRoute = Screen.Articles.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = unreadNotificationsCount,
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (feedError != null) {
                item { ErrorBanner(feedError!!) }
            }
            item {
                Text(
                    "Research and briefs shared by the community",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted
                )
                Spacer(Modifier.height(12.dp))
                GoldButton("Write an article", onClick = { onNavigate(Screen.ArticleEditor.createRoute()) })
            }
            if (articles.isEmpty()) {
                item {
                    LawEmptyState(
                        icon = { Icon(Icons.Default.Article, contentDescription = null, tint = GoldAccent) },
                        title = if (feedError == null) "No articles yet" else "Articles unavailable",
                        description = if (feedError == null) {
                            "Published research and legal briefs will appear here."
                        } else {
                            "Check your connection or try again later."
                        }
                    )
                }
            }
            items(articles, key = { it.id }) { article ->
                LawGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onArticleSelected(article.id) }
                ) {
                    Column {
                        Text(article.category.uppercase(), color = GoldAccent, style = MaterialTheme.typography.labelSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(article.title, color = TextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(article.content.take(220).ifBlank { "No article preview available." }, color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "${article.author}  ·  ${article.wordCount} words",
                            color = TextMuted,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ArticleDetailScreen(
    articleId: String,
    repository: ArticlesRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0
) {
    var article by remember(articleId) { mutableStateOf<Article?>(null) }
    var error by remember(articleId) { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var actionError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(articleId) {
        when (val result = repository.getArticleById(articleId)) {
            is Result.Success -> article = result.data
            is Result.Error -> error = result.message
            Result.Loading -> Unit
        }
    }
    val canManage = article?.let {
        it.authorUid == sessionState.uid || sessionState.isPlatformAdmin
    } == true

    AppScreenScaffold(
        title = article?.title?.take(22) ?: "Article",
        currentRoute = Screen.Articles.route,
        onNavigate = onNavigate,
        onBack = onBack,
        unreadNotificationsCount = unreadNotificationsCount,
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (error != null) item { ErrorBanner(error!!) }
            if (actionError != null) item { ErrorBanner(actionError!!) }
            val articleData = article
            if (articleData == null && error == null) {
                item { Text("Loading article…", color = TextMuted) }
            } else if (articleData != null) {
                item {
                    LawGlassCard(Modifier.fillMaxWidth()) {
                        Column {
                            Text(articleData.category.uppercase(), color = GoldAccent, style = MaterialTheme.typography.labelSmall)
                            Spacer(Modifier.height(8.dp))
                            Text(articleData.title, color = TextPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("${articleData.author} · ${articleData.wordCount} words", color = TextMuted, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(20.dp))
                            Text(articleData.content, color = TextPrimary, style = MaterialTheme.typography.bodyLarge, lineHeight = 26.sp)
                        }
                    }
                }
                if (canManage) item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GoldOutlinedButton("Edit", onClick = { onEdit(articleData.id) }, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Delete, contentDescription = null)
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete article?") },
            text = { Text("This removes the article from the shared archive.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launch {
                        when (val result = repository.deleteArticle(articleId, sessionState.uid.orEmpty(), sessionState.email)) {
                            is Result.Success -> onBack()
                            is Result.Error -> actionError = result.message
                            Result.Loading -> Unit
                        }
                    }
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ArticleEditorScreen(
    articleId: String?,
    repository: ArticlesRepository,
    sessionState: AuthSessionState,
    onNavigate: (String) -> Unit,
    onBack: () -> Unit,
    onSaved: (String) -> Unit
) {
    var title by remember(articleId) { mutableStateOf("") }
    var category by remember(articleId) { mutableStateOf("Student Research") }
    var content by remember(articleId) { mutableStateOf("") }
    var submissionId by remember(articleId) { mutableStateOf(UUID.randomUUID().toString()) }
    var isLoading by remember(articleId) { mutableStateOf(articleId != null) }
    var isSaving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val wordCount = content.trim().split(Regex("\\s+")).count { it.isNotBlank() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(articleId) {
        if (articleId != null) {
            when (val result = repository.getArticleById(articleId)) {
                is Result.Success -> {
                    if (result.data.authorUid != sessionState.uid && !sessionState.isPlatformAdmin) {
                        error = "You do not have permission to edit this article."
                    } else {
                        title = result.data.title
                        category = result.data.category
                        content = result.data.content
                    }
                }
                is Result.Error -> error = result.message
                Result.Loading -> Unit
            }
            isLoading = false
        }
    }

    AppScreenScaffold(
        title = if (articleId == null) "Write Article" else "Edit Article",
        currentRoute = Screen.Articles.route,
        onNavigate = onNavigate,
        onBack = onBack
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (error != null) item { ErrorBanner(error!!) }
            item {
                LawTextField(
                    value = title,
                    onValueChange = {
                        title = it.take(240)
                        submissionId = UUID.randomUUID().toString()
                    },
                    label = "Title",
                    placeholder = "Article title"
                )
            }
            item {
                LawTextField(
                    value = category,
                    onValueChange = {
                        category = it.take(100)
                        submissionId = UUID.randomUUID().toString()
                    },
                    label = "Category",
                    placeholder = "Student Research"
                )
            }
            item {
                LawTextField(
                    value = content,
                    onValueChange = {
                        content = it
                        submissionId = UUID.randomUUID().toString()
                    },
                    label = "Article text",
                    placeholder = "Write your research or legal brief…",
                    singleLine = false,
                    maxLines = 20,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
                )
            }
            item {
                Text(
                    text = if (articleId == null) {
                        "Word count: $wordCount / 500 minimum"
                    } else {
                        "Word count: $wordCount"
                    },
                    color = TextMuted
                )
            }
            item {
                GoldButton(
                    text = if (articleId == null) "Publish" else "Save changes",
                    isLoading = isSaving || isLoading,
                    enabled = title.isNotBlank() && content.isNotBlank() && error == null &&
                        (articleId != null || wordCount >= 500),
                    onClick = {
                        val uid = sessionState.uid
                        if (uid.isNullOrBlank()) {
                            error = "Your session has expired. Sign in again to publish."
                            return@GoldButton
                        }
                        isSaving = true
                        error = null
                        scope.launch {
                            val result = if (articleId == null) {
                                repository.publishArticle(
                                    title = title,
                                    category = category,
                                    content = content,
                                    submissionId = submissionId
                                ).let { publishResult ->
                                    when (publishResult) {
                                        is Result.Success -> Result.Success(publishResult.data)
                                        is Result.Error -> publishResult
                                        Result.Loading -> Result.Loading
                                    }
                                }
                            } else {
                                when (val update = repository.updateArticle(
                                    articleId, title, category, content, uid, sessionState.email
                                )) {
                                    is Result.Success -> Result.Success(articleId)
                                    is Result.Error -> update
                                    Result.Loading -> Result.Loading
                                }
                            }
                            isSaving = false
                            when (result) {
                                is Result.Success -> onSaved(result.data)
                                is Result.Error -> error = result.message
                                Result.Loading -> Unit
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun ResourcesScreen(
    repository: ResourcesRepository,
    onNavigate: (String) -> Unit,
    unreadNotificationsCount: Int = 0,
    unreadMessagesCount: Int = 0
) {
    val context = LocalContext.current
    var feedError by remember(repository) { mutableStateOf<String?>(null) }
    val newsFlow = remember(repository) {
        repository.observeLiveLegalNews().catch { error ->
            feedError = error.localizedMessage ?: "Unable to load legal updates from the server."
            emit(emptyList())
        }
    }
    val news by newsFlow.collectAsState(initial = emptyList())
    AppScreenScaffold(
        title = "Legal Resources",
        currentRoute = Screen.Resources.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = unreadNotificationsCount,
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (feedError != null) {
                item { ErrorBanner(feedError!!) }
            }
            item {
                Text("Trusted legal research links", color = TextMuted)
                Spacer(Modifier.height(8.dp))
            }
            items(repository.curatedResources) { resource ->
                LawGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(resource.url)))
                    }
                ) {
                    Column {
                        Row {
                            Icon(Icons.Default.Book, contentDescription = null, tint = GoldAccent)
                            Spacer(Modifier.padding(horizontal = 4.dp))
                            Text(resource.title, color = TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Icon(Icons.Default.OpenInNew, contentDescription = "Open link", tint = TextMuted)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(resource.description, color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Text(resource.category, color = GoldAccent, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text("LIVE LEGAL UPDATES", color = GoldAccent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            }
            if (news.isEmpty()) {
                item {
                    LawEmptyState(
                        icon = { Icon(Icons.Default.MenuBook, contentDescription = null, tint = GoldAccent) },
                        title = if (feedError == null) "No live updates" else "Live updates unavailable",
                        description = if (feedError == null) {
                            "New items appear here when the legal news feed is available."
                        } else {
                            "Check your connection or try again later."
                        }
                    )
                }
            }
            items(news, key = { it.id }) { item ->
                LawGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (item.link.isNotBlank()) {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.link)))
                        }
                    }
                ) {
                    Column {
                        Text(item.title, color = TextPrimary, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(item.summary, color = TextMuted, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Text("${item.source} · ${item.date}", color = GoldAccent, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationsScreen(
    repository: NotificationsRepository,
    currentUid: String,
    onNavigate: (String) -> Unit,
    onPostNotification: (String) -> Unit,
    unreadMessagesCount: Int = 0
) {
    val notifications by repository.observeNotifications(currentUid).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    AppScreenScaffold(
        title = "Notifications",
        currentRoute = Screen.Notifications.route,
        onNavigate = onNavigate,
        unreadNotificationsCount = notifications.count { !it.read },
        unreadMessagesCount = unreadMessagesCount
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (error != null) item { ErrorBanner(error!!) }
            if (notifications.isEmpty()) {
                item {
                    LawEmptyState(
                        icon = { Icon(Icons.Default.Notifications, contentDescription = null, tint = GoldAccent) },
                        title = "You’re all caught up",
                        description = "Your notifications will appear here."
                    )
                }
            }
            items(notifications, key = { it.id }) { notification ->
                NotificationCard(
                    notification = notification,
                    onClick = {
                        scope.launch {
                            when (val result = repository.markNotificationRead(currentUid, notification.id)) {
                                is Result.Error -> error = result.message
                                else -> Unit
                            }
                        }
                        notification.postId?.let(onPostNotification)
                    }
                )
            }
        }
    }
}

@Composable
private fun NotificationCard(notification: NotificationItem, onClick: () -> Unit) {
    LawGlassCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = if (!notification.read) GoldAccent.copy(alpha = 0.55f) else SurfaceGlassElevated,
        onClick = onClick
    ) {
        Column {
            Text(notification.title, color = TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(notification.body, color = TextMuted, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(6.dp))
            Text(formatTimestamp(notification.timestamp), color = GoldAccent, style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun formatTimestamp(timestamp: Long): String =
    if (timestamp > 0) DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(timestamp))
    else "Just now"
