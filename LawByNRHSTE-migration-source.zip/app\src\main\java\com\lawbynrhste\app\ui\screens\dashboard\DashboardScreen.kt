package com.lawbynrhste.app.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lawbynrhste.app.data.model.AuthSessionState
import com.lawbynrhste.app.data.repository.AdminRepository
import com.lawbynrhste.app.ui.components.LawBottomNavigationBar
import com.lawbynrhste.app.ui.components.LawGlassCard
import com.lawbynrhste.app.ui.components.LawTopAppBar
import com.lawbynrhste.app.ui.components.UserAvatar
import com.lawbynrhste.app.ui.navigation.Screen
import com.lawbynrhste.app.ui.theme.GoldAccent
import com.lawbynrhste.app.ui.theme.GoldLight
import com.lawbynrhste.app.ui.theme.Obsidian
import com.lawbynrhste.app.ui.theme.StateDanger
import com.lawbynrhste.app.ui.theme.StateWarning
import com.lawbynrhste.app.ui.theme.SurfaceBorder
import com.lawbynrhste.app.ui.theme.SurfaceBorderGold
import com.lawbynrhste.app.ui.theme.SurfaceGlass
import com.lawbynrhste.app.ui.theme.SurfaceGlassElevated
import com.lawbynrhste.app.ui.theme.TextMuted
import com.lawbynrhste.app.ui.theme.TextPrimary
import com.lawbynrhste.app.ui.theme.TextSecondary

@Composable
fun DashboardScreen(
    sessionState: AuthSessionState,
    adminRepository: AdminRepository,
    unreadNotificationsCount: Int,
    unreadMessagesCount: Int,
    onNavigate: (String) -> Unit
) {
    val maintenance by adminRepository.observeMaintenance().collectAsState(initial = null)
    val announcement by adminRepository.observeAnnouncement().collectAsState(initial = null)

    Scaffold(
        topBar = {
            LawTopAppBar(
                title = "LAWBY NRHSTE",
                unreadNotificationsCount = unreadNotificationsCount,
                onNotificationsClick = { onNavigate(Screen.Notifications.route) }
            )
        },
        bottomBar = {
            LawBottomNavigationBar(
                currentRoute = Screen.Dashboard.route,
                onNavigate = onNavigate,
                unreadMessagesCount = unreadMessagesCount
            )
        },
        containerColor = Obsidian
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(6.dp))

                // Maintenance alert banner
                if (maintenance?.active == true) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = StateWarning.copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StateWarning)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = StateWarning)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "SYSTEM MAINTENANCE: ${maintenance?.message}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StateWarning
                                )
                            )
                        }
                    }
                }

                // Greeting & Profile Header
                LawGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        UserAvatar(
                            name = sessionState.userAccount?.profile?.name ?: "User",
                            photoUrl = sessionState.userAccount?.profile?.photo,
                            size = 54.dp,
                            verification = sessionState.userAccount?.profile?.verification
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SECURE ACCESS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                            )
                            Text(
                                text = (sessionState.userAccount?.profile?.name ?: "Counsel").uppercase(),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Role: ${sessionState.userAccount?.profile?.role ?: "Student"}",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                            )
                        }
                    }
                }
            }

            // Live Platform Announcement
            item {
                LawGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (announcement != null) SurfaceBorderGold else SurfaceBorder
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = GoldAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PLATFORM ANNOUNCEMENTS",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = GoldAccent,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = announcement?.message ?: "No live announcements right now.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (announcement != null) TextPrimary else TextMuted
                            )
                        )
                    }
                }
            }

            // Quick Platform Destinations Grid
            item {
                Text(
                    text = "EXPEDITION & HUB",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = GoldAccent,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        DashboardShortcutCard(
                            title = "Legal Resources",
                            subtitle = "Courts, gazettes, SAFLII",
                            icon = Icons.Default.MenuBook,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(Screen.Resources.route) }
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        DashboardShortcutCard(
                            title = "Member Directory",
                            subtitle = "Find peers & counsel",
                            icon = Icons.Default.People,
                            modifier = Modifier.weight(1f),
                            onClick = { onNavigate(Screen.Directory.route) }
                        )
                    }

                    DashboardShortcutCard(
                        title = "Discussion Room",
                        subtitle = "Ask questions & debate current affairs",
                        icon = Icons.Default.Forum,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onNavigate(Screen.Discussions.route) }
                    )

                }
            }

            // Pillars
            item {
                Text(
                    text = "JURISPRUDENCE & FOUNDATIONS",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = GoldAccent,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                LawGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        PillarItem(
                            title = "Our Mission",
                            desc = "Cultivating a digital legal ecosystem for students and practitioners across South Africa.",
                            icon = Icons.Default.Shield
                        )
                        PillarItem(
                            title = "Core Values",
                            desc = "Integrity, Jurisprudence, Collaboration, and Zero Barriers to legal scholarship.",
                            icon = Icons.Default.Gavel
                        )
                        PillarItem(
                            title = "2026 Strategy",
                            desc = "Real-time legal communication, peer peer-mentorship, and accessible digital briefs.",
                            icon = Icons.Default.Explore
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun DashboardShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    LawGlassCard(
        modifier = modifier,
        onClick = onClick
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(SurfaceGlassElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = GoldAccent,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
            )
        }
    }
}

@Composable
fun PillarItem(
    title: String,
    desc: String,
    icon: ImageVector
) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = GoldLight,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = GoldAccent
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
            )
        }
    }
}
