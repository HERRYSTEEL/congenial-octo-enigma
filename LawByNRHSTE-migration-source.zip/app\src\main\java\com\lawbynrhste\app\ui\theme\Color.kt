package com.lawbynrhste.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Luxury Palette
val Obsidian = Color(0xFF05070A)
val SurfaceDark = Color(0xFF0C0E12)
val SurfaceGlass = Color(0x0AFFFFFF)
val SurfaceGlassElevated = Color(0x14FFFFFF)
val SurfaceBorder = Color(0x1AFFFFFF)
val SurfaceBorderGold = Color(0x33D4AF37)

// Gold Accents
val GoldAccent = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF3E5AB)
val GoldDark = Color(0xFFAA8C2C)
val GoldGlow = Color(0x40D4AF37)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFCCCCCC)
val TextMuted = Color(0xFF888888)
val TextDisabled = Color(0xFF555555)

// Status & Indicators
val StateFrozen = Color(0xFF00D4FF)
val StateDanger = Color(0xFFFF4444)
val StateWarning = Color(0xFFF1C40F)
val StateSuccess = Color(0xFF2ECC71)
val StateInfo = Color(0xFF1A73E8)

// Message Bubbles
val BubbleMe = Color(0xFFD4AF37)
val BubbleMeText = Color(0xFF000000)
val BubbleThem = Color(0xFF1C1C1E)
val BubbleThemText = Color(0xFFFFFFFF)

